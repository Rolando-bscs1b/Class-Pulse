# Live feedback and class section fixes

The installed ClassPulse app and the extracted project folder include the following updates.

## Student and teacher sign-ins

Student, teacher, and admin logins now use separate session cookies, scoped to this app's folder. You can keep student and teacher tabs open in the same browser. Signing in or logging out of one role does not sign out another role. Sign in once again after installing this update because older shared login cookies are no longer used.

Closing a feedback session does not log students out. The student page checks its session state every two seconds and disables submission when the teacher closes feedback. Unsent answers remain on that page while it stays open. A new lesson requires joining its new session before sending feedback, which prevents old drafts from being submitted to the wrong lesson.

## Automatic live feedback

Teacher dashboards refresh about every 1.5 seconds and immediately check again when the page regains focus. Same-browser submissions also notify the live dashboard directly. Status taps, mood check-ins, ratings, and written messages all appear in the anonymous feed. Only enrolled students can submit to a class section. Submission and session-closing operations use the same database lock, so closed lessons cannot accept a late response.

## Assign sections to existing records

Existing section assignments were not guessed. Set them through the admin screens:

1. Open **Admin → Students** and save each student's section, such as `BSCS-3B`.
2. Open **Admin → Classes**. Create one class entry per subject and section, even when the teacher and subject are the same. Existing entries can be labeled using the section field beside the instructor assignment.
3. Enroll students individually or use **Enroll a whole section**, which requires the student's assigned section to match the class section.
4. Use **Manage enrollments** on a class to remove incorrect class access and enroll the student in the correct class section. Removing an enrollment preserves the student account, feedback, and SET records. Individual enrollment remains available for irregular students.
5. In the teacher's live dashboard, select the subject and section and optionally enter a lesson/topic when starting a new session.

Section names appear in student classes, teacher cards, live dashboards, SET cards, evaluation details, and admin records. Sessions and responses are separated by class ID, so two sections of the same subject do not share feedback.

## SET charts

Admin SET includes a **View result charts** shortcut, evaluation counts, mean scores, instructor comparison bars on a fixed 0–5 axis, and a donut showing the distribution of individual question ratings. Each score appears alongside its response count; small samples are labeled. These are student-reported ratings rather than a ranking or a complete measure of teaching quality.

Teacher SET includes an anonymous rating-distribution chart for the selected class. The existing admin-release and minimum-three-evaluations requirements still apply. No student identities, individual ratings, or submission times are exposed in teacher results. Live feedback remains anonymous, including to admins. SET visibility remains controlled by the admin.

## Files and database

The active app is `C:\xampp\htdocs\ClassPulse-improved\classpulse`. The extracted copy is in this project's `ClassPulse-improved\classpulse` folder. The ZIP contains the updated files. Database migration `004_sections_live.sql` adds class sections, student sections, and lesson titles; the local database has already been upgraded. The pre-upgrade database backup is `ClassPulse-before-live-sections.sql`.

## Validation

Tested the complete open → submit → teacher feed → close workflow in a disposable database, including two sections of the same subject, stale submissions, status-only feedback, role-specific login/logout, bulk section enrollment, enrollment removal, and chart output. Browser checks confirmed automatic feed delivery and draft preservation after closure. The disposable database was separate from the user's records. PHP syntax checks, JavaScript behavior tests, both SET questionnaire versions, privacy gates, and feedback rendering checks passed.
