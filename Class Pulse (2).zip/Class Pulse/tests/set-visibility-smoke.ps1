param([string]$BaseUrl = 'http://localhost/ClassPulse-improved/classpulse')
. "$PSScriptRoot\portals-smoke.ps1" -BaseUrl $BaseUrl
$visibilitySession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$visibilityLogin = Sign-In 'admin' 'admin@cvsu.edu.ph' 'admin123' $visibilitySession
function Change-SetVisibility([string]$Enabled) {
    $settings = Invoke-WebRequest "$BaseUrl/admin/evaluations.php" -WebSession $visibilitySession
    $token = [regex]::Match($settings.Content, 'name="csrf" value="([^"]+)"').Groups[1].Value
    Invoke-WebRequest "$BaseUrl/admin/evaluations.php" -Method Post -Body @{csrf=$token;action='visibility';enabled=$Enabled} -WebSession $visibilitySession
}
try {
    $hidden = Change-SetVisibility '0'
    Assert-Page $hidden 'SET is hidden'
    foreach ($check in @(@('classes.php',$studentSession),@('teacher/index.php',$teacherSession))) {
        $dashboard=Invoke-WebRequest "$BaseUrl/$($check[0])" -WebSession $check[1]
        if ($dashboard.Content -match 'set-dashboard-callout|Teaching evaluation \(SET\)|My SET results') { throw 'SET is visible when disabled' }
    }
    Assert-Page (Invoke-WebRequest "$BaseUrl/set.php" -WebSession $studentSession) 'Your student space'
    Assert-Page (Invoke-WebRequest "$BaseUrl/teacher/evaluations.php" -WebSession $teacherSession) 'Your teaching space'
    $staleForm=Invoke-WebRequest "$BaseUrl/set.php?class_id=1" -Method Post -Body @{} -WebSession $studentSession -SkipHttpErrorCheck
    if ($staleForm.StatusCode -ne 403) { throw 'Disabled SET accepted a stale submission' }
    $invalidToggle=Invoke-WebRequest "$BaseUrl/admin/evaluations.php" -Method Post -Body @{action='visibility';enabled='1'} -WebSession $visibilitySession -SkipHttpErrorCheck
    if ($invalidToggle.StatusCode -ne 403) { throw 'Visibility toggle accepted missing CSRF' }
    $visible=Change-SetVisibility '1'; Assert-Page $visible 'SET is visible'
    $studentsVisible=Invoke-WebRequest "$BaseUrl/classes.php" -WebSession $studentSession
    Assert-Page $studentsVisible 'Teaching evaluation (SET)'
    $teachersVisible=Invoke-WebRequest "$BaseUrl/teacher/index.php" -WebSession $teacherSession
    Assert-Page $teachersVisible 'My SET results'
    Assert-Page (Invoke-WebRequest "$BaseUrl/set.php" -WebSession $studentSession) 'My Evaluation Tasks'
    Assert-Page (Invoke-WebRequest "$BaseUrl/teacher/evaluations.php" -WebSession $teacherSession) 'My Teaching Evaluations'
} finally {
    $final=Change-SetVisibility '0'; Assert-Page $final 'SET is hidden'
}
Write-Host 'PASS: admin toggle, hidden dashboards and navigation, blocked direct access and stale POST, re-enabled access, CSRF protection. SET left hidden.'
