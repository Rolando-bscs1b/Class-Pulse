param([string]$BaseUrl = 'http://127.0.0.1:8792/classpulse')
$ErrorActionPreference='Stop'
$qaHealth=Invoke-RestMethod (([uri]$BaseUrl).GetLeftPart([System.UriPartial]::Authority)+'/__qa_health')
if ($qaHealth.qa_database -notmatch '^classpulse_qa_[a-f0-9]{8}$') { throw 'These write tests require a disposable QA database.' }
function Check($Value,[string]$Message) { if (!$Value) { throw $Message } }
function Page([string]$Path,$Jar) { $page=Invoke-WebRequest "$BaseUrl/$Path" -WebSession $Jar; Check ($page.Content -notmatch 'Fatal error|Warning:') "Page failed: $Path"; return $page }
function Token($Page) { return [regex]::Match($Page.Content,'(?:name="csrf"|id="csrf") value="([^"]+)"').Groups[1].Value }
function Login([string]$Role,[string]$Email,[string]$Password,$Jar) {
    $route=if($Role -eq 'student'){'login.php'}else{"$Role/login.php"};$loginPage=Page $route $Jar
    $body=@{csrf=(Token $loginPage);password=$Password}; if($Role -eq 'student'){$body.identifier=$Email}else{$body.email=$Email}
    $result=Invoke-WebRequest "$BaseUrl/$route" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body $body -WebSession $Jar
    Check ($result.Content -notmatch 'Invalid email|Invalid student|Fatal error') "$Role sign-in failed"
}
$jar=New-Object Microsoft.PowerShell.Commands.WebRequestSession
Login 'student' '2023-0001' 'student123' $jar
Login 'teacher' 'santos@cvsu.edu.ph' 'teacher123' $jar
Check ((Page 'classes.php' $jar).Content -match 'YOUR STUDENT SPACE') 'Teacher login removed student sign-in'
Check ((Page 'teacher/index.php' $jar).Content -match 'YOUR TEACHING SPACE') 'Student session replaced teacher sign-in'
$dashboard=Page 'teacher/dashboard.php?class_id=1' $jar; $teacherToken=Token $dashboard
Check ($dashboard.Content -match 'BSCS-3B') 'Teacher dashboard lacks section label'
$start=Invoke-WebRequest "$BaseUrl/teacher/dashboard.php?class_id=1" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$teacherToken;act='start';lesson_title='Joins and relationships'} -WebSession $jar
$state=Invoke-RestMethod "$BaseUrl/api/session-status.php?class_id=1" -WebSession $jar
Check ($state.open -and $state.session.lesson_title -eq 'Joins and relationships') 'Student cannot see open lesson session'
$sessionId=$state.session.id
$studentFeedback=Page 'feedback.php?class_id=1' $jar; $studentToken=Token $studentFeedback
$body=@{csrf=$studentToken;class_id=1;session_id=$sessionId;status='following';mood=5;message='The practical examples are helpful.';ratings=@{};categories=@()}
$sent=Invoke-RestMethod "$BaseUrl/api/submit.php" -Method Post -Body ($body|ConvertTo-Json -Depth 5) -ContentType 'application/json' -WebSession $jar
Check $sent.ok 'Student feedback was not accepted'
$stats=Invoke-RestMethod "$BaseUrl/api/stats.php?class_id=1&role=teacher" -WebSession $jar
Check ($stats.count -eq 1 -and $stats.feed[0].message -eq $body.message) 'Teacher stats did not update immediately after submission'
Check (($stats|ConvertTo-Json -Depth 8) -notmatch 'student_id|student_number') 'Live stats expose student identity'
$third=New-Object Microsoft.PowerShell.Commands.WebRequestSession;Login 'student' '2023-0003' 'student123' $third
$thirdPage=Page 'feedback.php?class_id=1' $third
$statusOnly=@{csrf=(Token $thirdPage);class_id=1;session_id=$sessionId;status='confused';mood=$null;message='';ratings=@{};categories=@()}
$tap=Invoke-RestMethod "$BaseUrl/api/submit.php" -Method Post -Body ($statusOnly|ConvertTo-Json -Depth 5) -ContentType 'application/json' -WebSession $third
$stats=Invoke-RestMethod "$BaseUrl/api/stats.php?class_id=1&role=teacher" -WebSession $jar
Check ($stats.count -eq 2 -and $stats.feed[0].status -eq 'confused' -and $null -eq $stats.feed[0].message) 'Status-only feedback is missing from the live feed'
$otherDashboard=Page 'teacher/dashboard.php?class_id=5' $jar
Check ($otherDashboard.Content -match 'BSCS-3A') 'Second section not distinguishable'
Check ((Token $otherDashboard) -eq $teacherToken) 'Teacher CSRF changed during student activity'
$startOther=Invoke-WebRequest "$BaseUrl/teacher/dashboard.php?class_id=5" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$teacherToken;act='start';lesson_title='Section A lesson'} -WebSession $jar
$otherStats=Invoke-RestMethod "$BaseUrl/api/stats.php?class_id=5&role=teacher" -WebSession $jar
Check ($otherStats.count -eq 0) 'Feedback mixed between sections of the same subject'
$otherAccess=Invoke-WebRequest "$BaseUrl/api/session-status.php?class_id=5" -WebSession $jar -SkipHttpErrorCheck
Check ($otherAccess.StatusCode -eq 403) 'Student accessed an unenrolled class section'
$foreignStats=Invoke-WebRequest "$BaseUrl/api/stats.php?class_id=2&role=teacher" -WebSession $jar -SkipHttpErrorCheck
Check ($foreignStats.StatusCode -eq 403) 'Teacher accessed another instructor class'
$close=Invoke-WebRequest "$BaseUrl/teacher/dashboard.php?class_id=1" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$teacherToken;act='stop'} -WebSession $jar
$closedState=Invoke-RestMethod "$BaseUrl/api/session-status.php?class_id=1" -WebSession $jar
Check (!$closedState.open) 'Student status did not detect closed feedback'
$closedPage=Page 'feedback.php?class_id=1' $jar
Check ($closedPage.Content -match 'Closing feedback does not log you out' -and $closedPage.Content -notmatch '<title>Student Login') 'Closing a lesson returned the student to login'
$stale=Invoke-WebRequest "$BaseUrl/api/submit.php" -Method Post -Body ($body|ConvertTo-Json -Depth 5) -ContentType 'application/json' -WebSession $jar -SkipHttpErrorCheck
Check ($stale.StatusCode -eq 409) 'Closed session accepted stale feedback'
Check ((Page 'classes.php' $jar).Content -match 'YOUR STUDENT SPACE') 'Student session lost after closing feedback'
$teacherSet=Page 'teacher/evaluations.php?period_id=1&class_id=1' $jar
Check ($teacherSet.Content -match 'Rating distribution' -and $teacherSet.Content -notmatch 'student1@cvsu.edu.ph|student_number') 'Teacher SET chart missing or identity exposed'
Login 'admin' 'admin@cvsu.edu.ph' 'admin123' $jar
$adminSet=Page 'admin/evaluations.php?period_id=1' $jar
Check ($adminSet.Content -match 'Results by instructor' -and $adminSet.Content -match 'Rating distribution' -and $adminSet.Content -match 'Limited feedback') 'Admin evaluation charts lack useful context'
$adminToken=Token $adminSet
$newSection='BSCS-3C-'+[guid]::NewGuid().ToString('N').Substring(0,4)
$addClass=Invoke-WebRequest "$BaseUrl/admin/manage.php?t=classes" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$adminToken;act='add_class';code='ITD 101';title='Web Development';teacher_id=1;section_name=$newSection} -WebSession $jar
Check ($addClass.Content -match [regex]::Escape($newSection)) 'Admin cannot create another section of the same subject'
$classId=[regex]::Match($addClass.Content,('value="(\d+)">ITD 101 · '+[regex]::Escape($newSection))).Groups[1].Value
Check ($classId -ne '') 'New class section not selectable for enrollment'
$assignStudent=Invoke-WebRequest "$BaseUrl/admin/manage.php?t=students" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$adminToken;act='student_section';id=5;section_name=$newSection} -WebSession $jar
$bulk=Invoke-WebRequest "$BaseUrl/admin/manage.php?t=classes" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$adminToken;act='enroll_section';class_id=$classId;section_name=$newSection} -WebSession $jar
Check ($bulk.Content -match [regex]::Escape("1 students enrolled in $newSection")) 'Section bulk enrollment failed'
$enrollments=Page "admin/enrollments.php?class_id=$classId" $jar
Check ($enrollments.Content -match '2023-0005') 'Enrollment management cannot see the section student'
$remove=Invoke-WebRequest "$BaseUrl/admin/enrollments.php?class_id=$classId" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$adminToken;act='remove';student_id=5} -WebSession $jar
Check ($remove.Content -match 'Enrollment removed' -and $remove.Content -notmatch '2023-0005') 'Incorrect enrollment could not be removed'
$reenroll=Invoke-WebRequest "$BaseUrl/admin/manage.php?t=classes" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body @{csrf=$adminToken;act='enroll';class_id=$classId;number='2023-0005'} -WebSession $jar
$logoutTeacher=Page 'teacher/logout.php' $jar
Check ((Page 'classes.php' $jar).Content -match 'YOUR STUDENT SPACE') 'Teacher logout logged out student'
Check ((Page 'admin/index.php' $jar).Content -match 'School overview') 'Teacher logout logged out admin'
$loggedOutStats=Invoke-WebRequest "$BaseUrl/api/stats.php?class_id=1&role=teacher" -WebSession $jar -SkipHttpErrorCheck
Check ($loggedOutStats.StatusCode -eq 401) 'Logged-out teacher can still poll live stats'
Write-Host 'PASS: same-browser role sessions, open/submit/auto-stats/close flow, status-only feed, lesson titles, section isolation, enrollment control, SET charts, anonymous teacher data, and role-specific logout.'
