const {readFileSync} = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
function node(value='') {
  const classes = new Set();
  return {value,textContent:'',innerHTML:'Send feedback',dataset:{v:value},attributes:{},disabled:false,
    classList:{add:k=>classes.add(k),remove:k=>classes.delete(k),contains:k=>classes.has(k),toggle(k){if(classes.has(k))classes.delete(k);else classes.add(k);}},
    setAttribute(k,v){this.attributes[k]=v;},removeAttribute(k){delete this.attributes[k];},focus(){this.focused=true;}};
}
const status = ['confused','following','bored'].map(node), moods = ['1','2','3','4','5'].map(node), cats = ['Too fast','Good pace'].map(node);
const nodes = Object.fromEntries(['fb','status','mood','message','count','csrf','msg','done','again'].map(id=>[id,node()]));
const submit=node();
nodes.status.querySelectorAll=()=>status; nodes.mood.querySelectorAll=()=>moods;
nodes.fb.dataset.class='1'; nodes.fb.dataset.session='7'; nodes.csrf.value='test-token';
nodes.fb.querySelector=selector=>selector.includes('submit')?submit:null;
let release, calls=0, payload;
const context = vm.createContext({document:{getElementById:id=>nodes[id],querySelectorAll:()=>cats},location:{reload(){}},fetch:async(_url,options)=>{calls++;payload=JSON.parse(options.body);return new Promise(resolve=>{release=resolve;});}});
vm.runInContext(readFileSync('app/classpulse/assets/student.js','utf8'),context);
(async()=>{
  await nodes.fb.onsubmit({preventDefault(){}});
  assert.equal(calls,0); assert.equal(nodes.msg.textContent,'Please choose at least one response.');
  status[0].onclick(); status[1].onclick();
  assert.equal(status[0].attributes['aria-pressed'],'false'); assert.equal(status[1].attributes['aria-pressed'],'true');
  moods[4].onclick(); cats[0].onclick();
  assert.equal(cats[0].attributes['aria-pressed'],'true');
  nodes.message.value='A helpful lesson'; nodes.message.oninput();
  assert.equal(nodes.count.textContent,'16/500');
  const pending=nodes.fb.onsubmit({preventDefault(){}});
  assert.equal(submit.disabled,true); assert.equal(nodes.fb.attributes['aria-busy'],'true');
  await nodes.fb.onsubmit({preventDefault(){}}); assert.equal(calls,1);
  assert.equal(payload.status,'following'); assert.equal(payload.mood,5); assert.deepEqual(payload.categories,['Too fast']);
  assert.equal(payload.session_id,7);
  release({ok:true,json:async()=>({ok:true})}); await pending;
  assert.ok(nodes.fb.classList.contains('d-none')); assert.equal(nodes.done.focused,true); assert.equal(submit.disabled,false);
  const failed=nodes.fb.onsubmit({preventDefault(){}});
  release({ok:false,json:async()=>({error:'Feedback is closed for this class'})}); await failed;
  assert.equal(nodes.msg.textContent,'Feedback is closed for this class'); assert.equal(submit.disabled,false);
  assert.equal(nodes.fb.attributes['aria-busy'],undefined);
  console.log('PASS: accessible selection, validation, counter, duplicate-submit prevention, success focus, server-error recovery.');
})().catch(error=>{console.error(error);process.exitCode=1;});
