<?php
// CLI-only, read-only smoke check. Uses an isolated temporary login session.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../app/classpulse/config.php';
$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$cid = $pdo->query('SELECT id FROM classes ORDER BY code LIMIT 1')->fetchColumn();
if (!$cid) exit("No classes available for smoke check.\n");
session_save_path(sys_get_temp_dir());
session_id('classpulse-test-'.bin2hex(random_bytes(8)));
session_start();
$_SESSION['admin_id'] = 1;
$sessionFile = session_save_path().DIRECTORY_SEPARATOR.'sess_'.session_id();
session_write_close();
register_shutdown_function(function () use ($sessionFile) {
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    if (is_file($sessionFile)) unlink($sessionFile);
});
$_GET['class_id'] = $cid;
$_SERVER['REQUEST_METHOD'] = 'GET';
require __DIR__ . '/../app/classpulse/api/stats.php';
