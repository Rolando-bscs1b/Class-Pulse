<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__.'/../app/classpulse/config.php';
$pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
foreach (['001_set.sql','002_set_visibility.sql','003_set_reference.sql','004_sections_live.sql'] as $migration) foreach (array_filter(array_map('trim',explode(';',file_get_contents(__DIR__.'/../app/classpulse/migrations/'.$migration)))) as $statement) {
    if (preg_match('/^ALTER TABLE (\w+) ADD COLUMN (\w+)/i',$statement,$match)) {
        $check=$pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=? AND table_name=? AND column_name=?'); $check->execute([DB_NAME,$match[1],$match[2]]); if ($check->fetchColumn()) continue;
    }
    $pdo->exec($statement);
}
echo 'SET schema installed in '.DB_NAME.'. Existing live feedback was not changed.'.PHP_EOL;
