param([string]$BaseUrl = 'http://localhost/ClassPulse-improved/classpulse')
$ErrorActionPreference = 'Stop'
function Assert-Page($Page, [string]$Text) {
    if ($Page.StatusCode -ne 200 -or $Page.Content -match 'Fatal error|Warning:' -or $Page.Content -notmatch [regex]::Escape($Text)) { throw "Page check failed: $Text" }
}
function Sign-In([string]$Role, [string]$Email, [string]$Password, $Session) {
    $url = "$BaseUrl/$Role/login.php"
    $page = Invoke-WebRequest -Uri $url -WebSession $Session
    $token = [regex]::Match($page.Content, 'name="csrf" value="([^"]+)"').Groups[1].Value
    Invoke-WebRequest -Uri $url -Method Post -Body @{csrf=$token;email=$Email;password=$Password} -WebSession $Session
}
$adminSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$admin = Sign-In 'admin' 'admin@cvsu.edu.ph' 'admin123' $adminSession
Assert-Page $admin 'School overview'
if ($admin.Content -match '../teacher/dashboard.php') { throw 'Admin links into teacher portal' }
$insights = Invoke-WebRequest "$BaseUrl/admin/dashboard.php?class_id=2" -WebSession $adminSession
Assert-Page $insights 'Admin Class Insights'
foreach ($tab in @('instructors','classes','students')) {
    Assert-Page (Invoke-WebRequest "$BaseUrl/admin/manage.php?t=$tab" -WebSession $adminSession) 'Admin portal'
}
$teacherRoute = Invoke-WebRequest "$BaseUrl/teacher/dashboard.php" -WebSession $adminSession
Assert-Page $teacherRoute 'Instructor Login'
Write-Host 'PASS: admin overview, management pages, own insights route; teacher route requires teacher login.'
$teacherSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$teacher = Sign-In 'teacher' 'santos@cvsu.edu.ph' 'teacher123' $teacherSession
Assert-Page $teacher 'Your teaching space'
if ($teacher.Content -match 'Computer Fundamentals') { throw 'Teacher sees another instructor class' }
$live = Invoke-WebRequest "$BaseUrl/teacher/dashboard.php?class_id=1" -WebSession $teacherSession
Assert-Page $live 'Teacher Live Dashboard'
$foreignClass = Invoke-WebRequest "$BaseUrl/teacher/dashboard.php?class_id=2" -WebSession $teacherSession -SkipHttpErrorCheck
if ($foreignClass.StatusCode -ne 404) { throw 'Foreign class dashboard should be denied' }
$foreignStats = Invoke-WebRequest "$BaseUrl/api/stats.php?class_id=2" -WebSession $teacherSession -SkipHttpErrorCheck
if ($foreignStats.StatusCode -ne 403) { throw 'Foreign class stats should be forbidden' }
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/index.php" -WebSession $teacherSession) 'Admin Login'
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/dashboard.php" -WebSession $teacherSession) 'Admin Login'
$invalidAction = Invoke-WebRequest "$BaseUrl/teacher/dashboard.php?class_id=1" -Method Post -Body @{act='stop'} -WebSession $teacherSession -SkipHttpErrorCheck
if ($invalidAction.StatusCode -ne 403) { throw 'Missing CSRF was not rejected' }
Write-Host 'PASS: teacher overview, own live route; foreign classes, admin pages, and invalid forms denied.'
$switched = Sign-In 'teacher' 'santos@cvsu.edu.ph' 'teacher123' $adminSession
Assert-Page $switched 'Your teaching space'
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/index.php" -WebSession $adminSession) 'School overview'
Write-Host 'PASS: admin and teacher sign-ins coexist in separate role sessions.'
$studentSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$studentLogin = Invoke-WebRequest "$BaseUrl/login.php" -WebSession $studentSession
$studentToken = [regex]::Match($studentLogin.Content, 'name="csrf" value="([^"]+)"').Groups[1].Value
$studentHome = Invoke-WebRequest "$BaseUrl/login.php" -Method Post -Body @{csrf=$studentToken;identifier='2023-0001';password='student123'} -WebSession $studentSession
Assert-Page $studentHome 'Your student space'
Assert-Page (Invoke-WebRequest "$BaseUrl/feedback.php?class_id=1" -WebSession $studentSession) 'A safe space for your perspective'
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/index.php" -WebSession $studentSession) 'Admin Login'
foreach ($asset in @('style.css','ui.js','student.js','teacher.js')) {
    $response = Invoke-WebRequest "$BaseUrl/assets/$asset"
    if ($response.StatusCode -ne 200) { throw "Missing asset: $asset" }
}
Write-Host 'PASS: student login, classes, feedback page, admin restrictions, and shared assets.'
