<?php
if (PHP_SAPI!=='cli') { http_response_code(404); exit; }
session_save_path(sys_get_temp_dir()); session_id('set-test-'.bin2hex(random_bytes(8)));
require_once __DIR__.'/../app/classpulse/includes/set.php';
$sessionFile=session_save_path().DIRECTORY_SEPARATOR.'sess_'.session_id();
register_shutdown_function(function () use ($sessionFile) { if (db()->inTransaction()) db()->rollBack(); if (session_status()===PHP_SESSION_ACTIVE) session_write_close(); if (is_file($sessionFile)) unlink($sessionFile); });
function check_set($value,$message) { if (!$value) throw new RuntimeException($message); }
function expect_set_error(callable $action,string $type) { try { $action(); } catch (Throwable $error) { if ($error instanceof $type) return; throw $error; } throw new RuntimeException('Expected '.$type); }
function render_set_page(string $path): string { ob_start(); require $path; return ob_get_clean(); }
function save_set_preview(string $name,string $html): void {
    $folder=__DIR__.'/previews'; if (!is_dir($folder)) mkdir($folder,0777,true);
    $html=str_replace(['href="/ClassPulse-improved/classpulse/assets/','src="/ClassPulse-improved/classpulse/assets/'],['href="http://localhost/ClassPulse-improved/classpulse/assets/','src="http://localhost/ClassPulse-improved/classpulse/assets/'],$html);
    file_put_contents($folder.'/'.$name.'.html',$html);
}
$tag=bin2hex(random_bytes(4)); $fixtures=[];
db()->beginTransaction();
try {
    db()->exec("UPDATE feature_settings SET enabled=1 WHERE name='set'");
    db()->exec('UPDATE set_periods SET is_open=0 WHERE is_open=1');
    db()->prepare('INSERT INTO set_periods (title) VALUES (?)')->execute(['SET QA '.$tag]); $periodId=(int)db()->lastInsertId();
    foreach ([1,2] as $n) { db()->prepare('INSERT INTO teachers (name,email,password_hash) VALUES (?,?,?)')->execute(['SET Teacher '.$n,'set-'.$tag.'-teacher'.$n.'@cvsu.edu.ph','test-only']); $teachers[$n]=(int)db()->lastInsertId(); }
    foreach ([1,2] as $n) { db()->prepare('INSERT INTO classes (code,title,teacher_id) VALUES (?,?,?)')->execute(['SET-QA-'.$n,'SET QA Class '.$n,$teachers[$n]]); $classes[$n]=(int)db()->lastInsertId(); }
    foreach ([1,2,3] as $n) { db()->prepare('INSERT INTO students (student_number,email,name,password_hash) VALUES (?,?,?,?)')->execute(['QA-'.$tag.'-'.$n,'set-'.$tag.'-student'.$n.'@cvsu.edu.ph','PRIVATE SET STUDENT '.$n,'test-only']); $students[$n]=(int)db()->lastInsertId(); db()->prepare('INSERT INTO enrollments (student_id,class_id) VALUES (?,?)')->execute([$students[$n],$classes[1]]); }
    $_SERVER['REQUEST_METHOD']='GET'; $_SESSION=['student_id'=>$students[1]]; $_GET=['period_id'=>$periodId,'class_id'=>$classes[1]];
    $_SERVER['SCRIPT_NAME']='/ClassPulse-improved/classpulse/set.php'; $_SERVER['SCRIPT_FILENAME']=realpath(__DIR__.'/../app/classpulse/set.php');
    $openForm=render_set_page(__DIR__.'/../app/classpulse/set.php'); check_set(substr_count($openForm,'class="set-rating-question"')===15,'New form must have 15 questions'); save_set_preview('student-form',$openForm);
    $input=array_fill_keys(array_keys(set_questions()),'5')+['teacher_id'=>$teachers[1],'comments'=>'Helpful explanations <script>bad()</script>'];
    foreach (['0','6','1.5',[],null] as $bad) { $invalid=$input; $invalid['q01']=$bad; expect_set_error(fn()=>set_submit($students[1],$classes[1],$periodId,$invalid),InvalidArgumentException::class); }
    $long=$input; $long['comments']=str_repeat('a',1501); expect_set_error(fn()=>set_submit($students[1],$classes[1],$periodId,$long),InvalidArgumentException::class);
    expect_set_error(fn()=>set_submit($students[1],$classes[2],$periodId,$input),DomainException::class);
    $wrong=$input; $wrong['teacher_id']=$teachers[2]; expect_set_error(fn()=>set_submit($students[1],$classes[1],$periodId,$wrong),DomainException::class);
    set_submit($students[1],$classes[1],$periodId,$input);
    expect_set_error(fn()=>set_submit($students[1],$classes[1],$periodId,$input),DomainException::class);
    $four=array_replace($input,array_fill_keys(array_keys(set_questions()),'4')); set_submit($students[2],$classes[1],$periodId,$four);
    db()->prepare('UPDATE set_periods SET is_open=0,results_released=1 WHERE id=?')->execute([$periodId]);
    $small=set_summary($teachers[1],$periodId,$classes[1]); check_set(!$small['visible'] && !$small['scores'] && !$small['comments'],'Small cohort leaked results');
    expect_set_error(fn()=>set_submit($students[3],$classes[1],$periodId,$input),DomainException::class);
    db()->prepare('UPDATE set_periods SET is_open=1,results_released=0 WHERE id=?')->execute([$periodId]);
    $three=array_replace($input,array_fill_keys(array_keys(set_questions()),'3')); set_submit($students[3],$classes[1],$periodId,$three);
    check_set(!set_summary($teachers[1],$periodId,$classes[1])['visible'],'Open cycle leaked results');
    db()->prepare('UPDATE set_periods SET is_open=0 WHERE id=?')->execute([$periodId]);
    check_set(!set_summary($teachers[1],$periodId,$classes[1])['visible'],'Unreleased cycle leaked results');
    db()->prepare('UPDATE set_periods SET results_released=1 WHERE id=?')->execute([$periodId]);
    $results=set_summary($teachers[1],$periodId,$classes[1]); check_set($results['visible'] && $results['total']===3 && $results['overall']===4.0,'Incorrect teacher aggregation');
    foreach (['student_id','student_number','student_name','submitted_at','evaluation_id'] as $secret) check_set(!str_contains(json_encode($results),$secret),'Teacher data contains '.$secret);
    check_set(set_summary($teachers[2],$periodId,$classes[1])['total']===0,'Another teacher can access responses');
    db()->prepare('UPDATE classes SET teacher_id=? WHERE id=?')->execute([$teachers[2],$classes[1]]);
    check_set(set_summary($teachers[1],$periodId,$classes[1])['total']===3 && set_summary($teachers[2],$periodId,$classes[1])['total']===0,'Reassignment transferred historical evaluations');
    $_SERVER['REQUEST_METHOD']='GET'; $_SESSION=['teacher_id'=>$teachers[1]]; $_GET=['period_id'=>$periodId,'class_id'=>$classes[1],'teacher_id'=>$teachers[2]];
    $_SERVER['SCRIPT_NAME']='/ClassPulse-improved/classpulse/teacher/evaluations.php'; $_SERVER['SCRIPT_FILENAME']=realpath(__DIR__.'/../app/classpulse/teacher/evaluations.php');
    $teacherHtml=render_set_page(__DIR__.'/../app/classpulse/teacher/evaluations.php');
    check_set(str_contains($teacherHtml,'4.00'),'Teacher score missing'); check_set(!str_contains($teacherHtml,'PRIVATE SET STUDENT') && !str_contains($teacherHtml,'QA-'.$tag),'Teacher HTML exposes student identity');
    check_set(str_contains($teacherHtml,'&lt;script&gt;bad()&lt;/script&gt;') && !str_contains($teacherHtml,'<script>bad()'),'Comments are not escaped');
    save_set_preview('teacher-results',$teacherHtml);
    $evaluationId=(int)db()->query('SELECT MAX(id) FROM teaching_evaluations')->fetchColumn();
    $_SESSION=['admin_id'=>1]; $_GET=['period_id'=>$periodId,'evaluation_id'=>$evaluationId];
    $_SERVER['SCRIPT_NAME']='/ClassPulse-improved/classpulse/admin/evaluations.php'; $_SERVER['SCRIPT_FILENAME']=realpath(__DIR__.'/../app/classpulse/admin/evaluations.php');
    $adminHtml=render_set_page(__DIR__.'/../app/classpulse/admin/evaluations.php');
    check_set(str_contains($adminHtml,'PRIVATE SET STUDENT 3') && str_contains($adminHtml,'QA-'.$tag.'-3'),'Admin cannot identify submission');
    save_set_preview('admin-review',$adminHtml);
    $_SESSION=['student_id'=>$students[1]]; $_GET=['class_id'=>$classes[1]];
    $_SERVER['SCRIPT_NAME']='/ClassPulse-improved/classpulse/set.php'; $_SERVER['SCRIPT_FILENAME']=realpath(__DIR__.'/../app/classpulse/set.php');
    $studentHtml=render_set_page(__DIR__.'/../app/classpulse/set.php');
    check_set(str_contains($studentHtml,'data-readonly="true"') && !str_contains($studentHtml,'type="submit"'),'Submitted class is not view-only');
    check_set(substr_count($studentHtml,'class="set-rating-question"')===15 && str_contains($studentHtml,'Always manifested') && str_contains($studentHtml,'D. Other Comments and Suggestions'),'Reference questionnaire incomplete');
    save_set_preview('student-completed',$studentHtml);
    $_GET=['period_id'=>$periodId]; $tasksHtml=render_set_page(__DIR__.'/../app/classpulse/set.php'); check_set(str_contains($tasksHtml,'SET Teacher 1'),'Completed task lost original instructor'); save_set_preview('student-tasks',$tasksHtml);
    $legacyPeriodTitle='Legacy QA '.$tag;
    db()->prepare('INSERT INTO set_periods (title,questionnaire_version) VALUES (?,1)')->execute([$legacyPeriodTitle]); $legacyId=(int)db()->lastInsertId();
    $legacyInput=array_fill_keys(array_keys(set_questions(1)),'2')+['teacher_id'=>$teachers[2],'strengths'=>'Legacy strengths','improvements'=>'Legacy suggestions'];
    foreach ($students as $studentId) set_submit($studentId,$classes[1],$legacyId,$legacyInput);
    db()->prepare('UPDATE set_periods SET is_open=0,results_released=1 WHERE id=?')->execute([$legacyId]);
    $legacySummary=set_summary($teachers[2],$legacyId,$classes[1]); check_set($legacySummary['overall']===2.0 && count($legacySummary['scores'])===8,'Legacy eight-question scores changed');
    $scoreSql=set_score_sql(); $scoreQuery=db()->prepare("SELECT AVG($scoreSql) FROM teaching_evaluations ev WHERE ev.period_id=?"); $scoreQuery->execute([$periodId]); check_set((float)$scoreQuery->fetchColumn()===4.0,'Admin modern score incorrect');
    $scoreQuery->execute([$legacyId]); check_set((float)$scoreQuery->fetchColumn()===2.0,'Admin legacy score incorrect');
    $_GET=['period_id'=>$legacyId,'class_id'=>$classes[1]];
    $legacyHtml=render_set_page(__DIR__.'/../app/classpulse/set.php'); check_set(substr_count($legacyHtml,'class="set-rating-question"')===8 && str_contains($legacyHtml,'Strongly agree'),'Legacy response relabeled');
    $future=(new DateTimeImmutable('now',new DateTimeZone('Asia/Manila')))->modify('+1 day')->format('Y-m-d H:i:s');
    db()->prepare('INSERT INTO set_periods (title,starts_at) VALUES (?,?)')->execute(['Scheduled QA '.$tag,$future]); $scheduledId=(int)db()->lastInsertId();
    check_set(set_task_status(set_period($scheduledId))==='pending','Future cycle not pending');
    expect_set_error(fn()=>set_submit($students[1],$classes[1],$scheduledId,array_replace($input,['teacher_id'=>$teachers[2]])),DomainException::class);
    db()->prepare('UPDATE set_periods SET starts_at=NULL,ends_at=? WHERE id=?')->execute([(new DateTimeImmutable('now',new DateTimeZone('Asia/Manila')))->modify('-1 day')->format('Y-m-d H:i:s'),$scheduledId]);
    check_set(set_task_status(set_period($scheduledId))==='closed','Expired cycle not closed');
    expect_set_error(fn()=>set_submit($students[1],$classes[1],$scheduledId,array_replace($input,['teacher_id'=>$teachers[2]])),DomainException::class);
    db()->exec("UPDATE feature_settings SET enabled=0 WHERE name='set'");
    $hidden=set_summary($teachers[1],$periodId,$classes[1]);
    check_set(!$hidden['visible'] && !$hidden['scores'] && !$hidden['comments'],'Disabled SET exposed result data');
    expect_set_error(fn()=>set_submit($students[1],$classes[1],$periodId,$input),DomainException::class);
    db()->rollBack();
    $q=db()->prepare('SELECT COUNT(*) FROM set_periods WHERE id=?'); $q->execute([$periodId]); check_set(!$q->fetchColumn(),'Fixtures not rolled back');
    echo "PASS: rating validation, enrollment, instructor snapshot, duplicate prevention, closed cycles, privacy threshold, release gating, aggregation, role-scoped data, escaped comments, admin identification, submitted state; all test records rolled back.\n";
} catch (Throwable $error) { if (db()->inTransaction()) db()->rollBack(); throw $error; }
