<?php
if (!preg_match('/^classpulse_qa_[a-f0-9]{8}$/D',getenv('CLASSPULSE_DB_NAME') ?: '')) { http_response_code(503); exit('QA server requires a disposable database.'); }
if (parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)==='/__qa_health') { header('Content-Type: application/json'); echo json_encode(['qa_database'=>getenv('CLASSPULSE_DB_NAME')]); return true; }
return false;
