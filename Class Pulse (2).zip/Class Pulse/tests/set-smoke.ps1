param([string]$BaseUrl = 'http://localhost/ClassPulse-improved/classpulse')
. "$PSScriptRoot\portals-smoke.ps1" -BaseUrl $BaseUrl
$studentSet = Invoke-WebRequest "$BaseUrl/set.php" -WebSession $studentSession
if ($studentSet.Content -notmatch 'My Evaluation Tasks') { Write-Host 'SET is hidden; run set-visibility-smoke.ps1 for the toggle checks.'; return }
Assert-Page $studentSet 'Anonymous to teachers. Identifiable to administrators.'
$form = Invoke-WebRequest "$BaseUrl/set.php?class_id=1" -WebSession $studentSession
if ($form.Content -notmatch 'id="set-form"' -or $form.Content -match 'data-readonly') { Write-Host 'No editable SET form in this cycle; use set-integration.php for questionnaire submission checks.'; return }
Assert-Page $form 'id="set-form"'
$questionKeys = @([regex]::Matches($form.Content, '<input type="radio"[^>]*name="([^"]+)"') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
if ($questionKeys.Count -notin @(8,15)) { throw 'Unexpected questionnaire version' }
$token = [regex]::Match($form.Content, 'name="csrf" value="([^"]+)"').Groups[1].Value
$periodId = [regex]::Match($form.Content, 'name="period_id" value="([^"]+)"').Groups[1].Value
$actualTeacher = [regex]::Match($form.Content, 'name="teacher_id" value="([^"]+)"').Groups[1].Value
$payload = @{csrf=$token;period_id=$periodId;teacher_id=$actualTeacher;comments='';strengths='';improvements=''}
foreach ($key in $questionKeys) { $payload[$key]='5' }; $payload[$questionKeys[0]]='6'
$invalid = Invoke-WebRequest "$BaseUrl/set.php?class_id=1" -Method Post -Body $payload -WebSession $studentSession
Assert-Page $invalid "Please rate all $($questionKeys.Count) statements from 1 to 5."
$payload[$questionKeys[0]]='5'; $payload.teacher_id='999999'
$changedTeacher = Invoke-WebRequest "$BaseUrl/set.php?class_id=1" -Method Post -Body $payload -WebSession $studentSession
Assert-Page $changedTeacher 'The assigned instructor changed.'
$noToken = Invoke-WebRequest "$BaseUrl/set.php?class_id=1" -Method Post -Body @{period_id=$periodId} -WebSession $studentSession -SkipHttpErrorCheck
if ($noToken.StatusCode -ne 403) { throw 'SET missing CSRF accepted' }
Assert-Page (Invoke-WebRequest "$BaseUrl/teacher/evaluations.php?class_id=1" -WebSession $teacherSession) 'Teaching Evaluation Results'
$foreign = Invoke-WebRequest "$BaseUrl/teacher/evaluations.php?class_id=2" -WebSession $teacherSession -SkipHttpErrorCheck
if ($foreign.StatusCode -ne 404) { throw 'Teacher can access another teacher class SET' }
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/evaluations.php?evaluation_id=1" -WebSession $teacherSession) 'Admin Login'
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/evaluations.php" -WebSession $studentSession) 'Admin Login'
Assert-Page (Invoke-WebRequest "$BaseUrl/teacher/evaluations.php" -WebSession $studentSession) 'Instructor Login'
$setAdminSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$adminLogin = Sign-In 'admin' 'admin@cvsu.edu.ph' 'admin123' $setAdminSession
Assert-Page $adminLogin 'School overview'
Assert-Page (Invoke-WebRequest "$BaseUrl/admin/evaluations.php" -WebSession $setAdminSession) 'Identified submissions'
$invalidAdmin = Invoke-WebRequest "$BaseUrl/admin/evaluations.php" -Method Post -Body @{action='close';period_id=$periodId} -WebSession $setAdminSession -SkipHttpErrorCheck
if ($invalidAdmin.StatusCode -ne 403) { throw 'Admin SET controls accepted missing CSRF' }
Write-Host 'PASS: SET dashboard entry, eight-question form, invalid input and instructor changes rejected, CSRF protection, teacher ownership, admin-only identified review; no evaluations submitted.'
