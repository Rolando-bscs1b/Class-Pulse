const {readFileSync}=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function node(){const classes=new Set();return {dataset:{},textContent:'',value:'Unsent draft',disabled:false,classList:{add:k=>classes.add(k),remove:k=>classes.delete(k),contains:k=>classes.has(k),toggle(k,force){if(force)classes.add(k);else classes.delete(k);}}};}
const ids=['feedback-live','live-fields','student-live-badge','live-notice','student-lesson','live-reload','live-closed','done'];
const nodes=Object.fromEntries(ids.map(id=>[id,node()])),form=node();form.dataset={class:'1',session:'7'};nodes['feedback-live'].dataset.class='1';nodes.done.classList.add('d-none');
let result={ok:true,status:200,json:async()=>({open:true,session:{id:7,lesson_title:'Lesson A'}})};
const context=vm.createContext({form,document:{getElementById:id=>nodes[id],addEventListener(){}},window:{addEventListener(){}},AbortController,setTimeout:()=>1,clearTimeout(){},fetch:async()=>result});
const source=readFileSync('app/classpulse/assets/student.js','utf8').split('const livePage=')[1];
vm.runInContext('const livePage='+source,context);
(async()=>{
  await new Promise(setImmediate);assert.equal(nodes['live-fields'].disabled,false);assert.equal(nodes['student-lesson'].textContent,'Lesson A');
  result={ok:true,status:200,json:async()=>({open:false,session:{id:7,lesson_title:'Lesson A'}})};await context.window.classPulseLive.refresh();
  assert.equal(nodes['live-fields'].disabled,true);assert.ok(nodes['live-notice'].textContent.includes('still signed in'));assert.equal(form.value,'Unsent draft');
  result={ok:true,status:200,json:async()=>({open:true,session:{id:8,lesson_title:'Lesson B'}})};await context.window.classPulseLive.refresh();
  assert.equal(nodes['live-fields'].disabled,true);assert.equal(nodes['live-reload'].classList.contains('d-none'),false);assert.equal(form.dataset.session,'7');
  form.dataset.session='0';await context.window.classPulseLive.refresh();assert.equal(form.dataset.session,'8');assert.equal(nodes['live-fields'].disabled,false);
  result={ok:false,status:401};await context.window.classPulseLive.refresh();assert.ok(nodes['live-notice'].textContent.includes('sign-in has expired'));assert.equal(nodes['live-fields'].disabled,true);
  console.log('PASS: automatic session state, closure preserves sign-in and draft, new-lesson protection, opening from closed state, expired-login messaging.');
})().catch(error=>{console.error(error);process.exitCode=1;});
