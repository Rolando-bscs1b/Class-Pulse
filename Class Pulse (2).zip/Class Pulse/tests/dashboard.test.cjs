const {readFileSync} = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const elements = new Map();
function element(id) {
  if (!elements.has(id)) {
    const classes = new Set();
    elements.set(id, {textContent:'',innerHTML:'',disabled:false,dataset:{class:'1'},addEventListener(){},classList:{add:k=>classes.add(k),remove:k=>classes.delete(k),contains:k=>classes.has(k),toggle(k,force){if(force)classes.add(k);else classes.delete(k);}}});
  }
  return elements.get(id);
}
let result;
const context = vm.createContext({document:{getElementById:element,querySelector:()=>element('dot')},AbortController,setTimeout:()=>1,clearTimeout(){},window:{confirm:()=>true},fetch:async()=>result});
const source = readFileSync('app/classpulse/assets/teacher.js','utf8').replace(/poll\(\);\s*$/, '');
vm.runInContext(source,context);
const data = {session:{id:1,started_at:'2026-11-06 09:00:00',ended_at:null},mood:4.2,count:5,participation:50,status:{confused:2,following:2,bored:1},eval:{clarity:4},feed:[{ago:0,message:'<img src=x onerror=alert(1)>'}],concerns:{'Need clarification':2},timeline:[{t:'2026-11-06 09:01',status:'confused',n:2}],server_time:'09:01:00'};
context.data = data;
vm.runInContext('render(data)',context);
assert.equal(element('mood').textContent,4.2);
assert.equal(element('close-session').disabled,false);
assert.ok(element('feed').innerHTML.includes('&lt;img'));
assert.ok(!element('feed').innerHTML.includes('<img'));
context.statusOnly={...data,feed:[{ago:0,message:null,status:'following',mood:4}]};
vm.runInContext('render(statusOnly)',context);
assert.ok(element('feed').innerHTML.includes('Following') && element('feed').innerHTML.includes('Mood 4 / 5') && !element('feed').innerHTML.includes('>null<'));
assert.ok(!element('alert').classList.contains('d-none'));
vm.runInContext('render({session:null,server_time:"09:02:00"})',context);
assert.equal(element('count').textContent,0);
assert.equal(element('part').textContent,'0%');
assert.equal(element('close-session').disabled,true);
assert.ok(element('alert').classList.contains('d-none'));
assert.ok(!element('timeline').innerHTML.includes('09:01'));
(async()=>{
  data.session.ended_at='2026-11-06 09:03:00';
  result={ok:true,status:200,json:async()=>data};
  await vm.runInContext('poll()',context);
  assert.equal(element('connTxt').textContent,'Session closed');
  assert.equal(element('close-session').disabled,true);
  result={ok:false,status:500};
  await vm.runInContext('poll()',context);
  assert.equal(element('connTxt').textContent,'Reconnecting…');
  assert.ok(!element('connection-error').classList.contains('d-none'));
  result={ok:true,status:200,json:async()=>data};
  await vm.runInContext('poll()',context);
  assert.ok(element('connection-error').classList.contains('d-none'));
  result={ok:false,status:401};
  await vm.runInContext('poll()',context);
  assert.equal(element('connTxt').textContent,'Access expired');
  assert.equal(element('refresh').disabled,true);
  console.log('PASS: rendering, escaping, empty-state reset, closed sessions, connection recovery, expired login');
})().catch(error=>{console.error(error);process.exitCode=1;});
