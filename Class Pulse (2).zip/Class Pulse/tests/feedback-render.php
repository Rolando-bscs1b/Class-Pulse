<?php
// Validate the open form inside a rolled-back transaction; save no class activity.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
session_save_path(sys_get_temp_dir());
session_id('classpulse-ui-'.bin2hex(random_bytes(8)));
require_once __DIR__.'/../app/classpulse/includes/bootstrap.php';
$sessionFile = session_save_path().DIRECTORY_SEPARATOR.'sess_'.session_id();
register_shutdown_function(function () use ($sessionFile) {
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    if (is_file($sessionFile)) unlink($sessionFile);
});
$enrollment = db()->query('SELECT student_id,class_id FROM enrollments ORDER BY class_id,student_id LIMIT 1')->fetch();
if (!$enrollment) throw new RuntimeException('An enrolled student is required.');
$_SESSION['student_id'] = $enrollment['student_id'];
$_GET['class_id'] = $enrollment['class_id'];
$_SERVER['SCRIPT_FILENAME'] = realpath(__DIR__.'/../app/classpulse/feedback.php');
$_SERVER['SCRIPT_NAME'] = '/ClassPulse-improved/classpulse/feedback.php';
db()->beginTransaction();
try {
    db()->prepare('INSERT INTO sessions (class_id) VALUES (?)')->execute([$enrollment['class_id']]);
    $sid = db()->lastInsertId();
    chdir(__DIR__.'/../app/classpulse');
    ob_start();
    require __DIR__.'/../app/classpulse/feedback.php';
    $html = ob_get_clean();
} finally { db()->rollBack(); }
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
foreach (['//button[@class="status-btn"]'=>3,'//button[@class="mood-btn"]'=>5,'//fieldset[@class="rate"]'=>5,'//input[@type="radio"]'=>25,'//button[@class="chip"]'=>8,'//label[@for="message"]'=>1] as $query=>$expected) {
    if ($xpath->query($query)->length !== $expected) throw new RuntimeException('Form check failed: '.$query);
}
$check = db()->prepare('SELECT COUNT(*) FROM sessions WHERE id=?'); $check->execute([$sid]);
if ($check->fetchColumn()) throw new RuntimeException('Test activity was not rolled back.');
echo "PASS: open feedback form, semantic controls, rating groups, labels; no test records saved.\n";
