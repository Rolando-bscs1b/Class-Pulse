<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../app/classpulse/config.php';
$pdo = new PDO('mysql:host='.DB_HOST.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$check = $pdo->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name=?');
$check->execute([DB_NAME]);
if ($check->fetchColumn()) { fwrite(STDERR, "Database already exists; no changes made.\n"); exit(1); }
ob_start();
require __DIR__ . '/../app/classpulse/setup.php';
ob_end_clean();
echo 'Created '.DB_NAME.PHP_EOL;
foreach (['admins','teachers','classes','students','enrollments','sessions','responses','participation'] as $table) {
    echo $table.': '.$pdo->query('SELECT COUNT(*) FROM `'.$table.'`')->fetchColumn().PHP_EOL;
}
foreach ([['admins','admin@cvsu.edu.ph','admin123'], ['teachers','santos@cvsu.edu.ph','teacher123'], ['students','student1@cvsu.edu.ph','student123']] as [$table,$email,$password]) {
    $q = $pdo->prepare('SELECT password_hash FROM `'.$table.'` WHERE email=?'); $q->execute([$email]);
    if (!password_verify($password, $q->fetchColumn())) throw new RuntimeException('Demo login validation failed');
}
echo "All demo login passwords verified.\n";
