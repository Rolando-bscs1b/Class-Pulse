<?php
// Disposable QA database only. Never points the app at the user's real data.
if (PHP_SAPI!=='cli') { http_response_code(404); exit; }
$action=$argv[1] ?? ''; $name=$argv[2] ?? '';
if (!preg_match('/^classpulse_qa_[a-f0-9]{8}$/D',$name) || !in_array($action,['create','drop'],true)) throw new RuntimeException('An explicitly named QA database is required.');
putenv('CLASSPULSE_DB_NAME='.$name);
require_once __DIR__.'/../app/classpulse/config.php';
$connection=new PDO('mysql:host='.DB_HOST.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$marker=__DIR__.'/'.$name.'.json';
if ($action==='drop') {
    $record=is_file($marker) ? json_decode(file_get_contents($marker),true) : null;
    if (!$record || ($record['database'] ?? '')!==$name || ($record['owner'] ?? '')!=='ClassPulse QA') throw new RuntimeException('No ownership marker for this disposable database.');
    $connection->exec('DROP DATABASE `'.$name.'`'); unlink($marker); echo "Removed disposable QA database.\n"; exit;
}
$q=$connection->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name=?'); $q->execute([$name]); if ($q->fetchColumn()) throw new RuntimeException('QA database already exists.');
ob_start(); require __DIR__.'/../app/classpulse/setup.php'; ob_end_clean();
file_put_contents($marker,json_encode(['database'=>$name,'owner'=>'ClassPulse QA']));
session_save_path(sys_get_temp_dir()); session_id('qa-'.bin2hex(random_bytes(8)));
require_once __DIR__.'/../app/classpulse/includes/set.php';
$sessionFile=session_save_path().DIRECTORY_SEPARATOR.'sess_'.session_id();
register_shutdown_function(function () use ($sessionFile) { if(session_status()===PHP_SESSION_ACTIVE) session_write_close(); if(is_file($sessionFile)) unlink($sessionFile); });
db()->exec("UPDATE classes SET section_name='BSCS-3B' WHERE id=1");
db()->exec("UPDATE classes SET section_name='BSCS-3A' WHERE id=4");
db()->exec("UPDATE students SET section_name='BSCS-3B' WHERE id<>2");
db()->exec("UPDATE students SET section_name='BSCS-3A' WHERE id=2");
db()->exec('DELETE FROM enrollments WHERE student_id=2 AND class_id=1');
db()->exec("INSERT INTO classes (code,title,teacher_id,section_name,department,schedule_code) VALUES ('ITD 101','Web Development',1,'BSCS-3A','Computer Studies','QA-3A')");
$sectionAId=(int)db()->lastInsertId(); db()->prepare('INSERT INTO enrollments (student_id,class_id) VALUES (2,?)')->execute([$sectionAId]);
db()->exec("UPDATE classes SET department='Computer Studies',schedule_code='QA-3B' WHERE id=1");
db()->exec("UPDATE feature_settings SET enabled=1 WHERE name='set'");
$period=set_period();
foreach ([1=>5,3=>4,4=>3] as $student=>$rating) {
    $input=array_fill_keys(array_keys(set_questions()),(string)$rating)+['teacher_id'=>1,'comments'=>['Clear examples help me understand the lessons.','More guided practice would be useful.','The activities are engaging and relevant.'][$rating-3]];
    set_submit($student,1,(int)$period['id'],$input);
}
$input=array_fill_keys(array_keys(set_questions()),'3')+['teacher_id'=>2,'comments'=>'More worked examples would help.']; $input['q01']='4'; set_submit(1,2,(int)$period['id'],$input);
db()->prepare('UPDATE set_periods SET is_open=0,results_released=1 WHERE id=?')->execute([$period['id']]);
echo json_encode(['database'=>$name,'section_a_class_id'=>$sectionAId,'set_period_id'=>$period['id']]).PHP_EOL;
