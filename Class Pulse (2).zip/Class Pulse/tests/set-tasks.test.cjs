const {readFileSync}=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
function element(dataset={}) { return {dataset,hidden:false,disabled:false,value:'',events:{},attrs:{},addEventListener(name,handler){this.events[name]=handler;},setAttribute(name,value){this.attrs[name]=value;}}; }
const cards=Array.from({length:20},(_,i)=>element({taskStatus:i<10?'available':'completed',taskSearch:`Teacher ${i} Course`}));
const search=element(),size=element(),previous=element(),next=element(),count=element(),empty=element();size.value='9';
const buttons=['all','available','completed'].map(status=>element({taskFilter:status}));
const tools={querySelector:selector=>selector.includes('search')?search:size,querySelectorAll:()=>buttons};
const context=vm.createContext({document:{querySelector:selector=>selector==='[data-task-tools]'?tools:({'[data-task-count]':count,'[data-task-prev]':previous,'[data-task-next]':next,'[data-task-empty]':empty}[selector]),querySelectorAll:()=>cards}});
vm.runInContext(readFileSync('app/classpulse/assets/set-tasks.js','utf8'),context);
assert.equal(cards.filter(card=>!card.hidden).length,9);assert.equal(previous.disabled,true);assert.equal(next.disabled,false);assert.equal(count.textContent,'Showing 1–9 of 20 evaluations');
next.events.click();assert.equal(count.textContent,'Showing 10–18 of 20 evaluations');
buttons[2].events.click();assert.equal(count.textContent,'Showing 1–9 of 10 evaluations');assert.equal(buttons[2].attrs['aria-pressed'],'true');
size.value='18';size.events.change();assert.equal(cards.filter(card=>!card.hidden).length,10);assert.equal(next.disabled,true);
search.value='Teacher 19';search.events.input();assert.equal(cards.filter(card=>!card.hidden).length,1);
search.value='no match';search.events.input();assert.equal(empty.hidden,false);assert.equal(count.textContent,'No matching evaluations');
search.value='';search.events.input();buttons[1].events.click();assert.equal(cards.filter(card=>!card.hidden).length,10);assert.equal(empty.hidden,true);
console.log('PASS: task search, status tabs, page sizes, pagination, counts, empty states.');
