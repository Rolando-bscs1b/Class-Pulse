# ClassPulse dashboard update

## Live feedback fixes section separation and SET charts

- Separated role-specific login sessions so teacher/student/admin tabs can coexist without clearing each other's sign-ins.
- Added student session-state polling, closed-session messaging, stale-lesson protection, and preservation of unsent answers on the open page. Closing feedback does not redirect to login.
- Teacher polling now refreshes about every 1.5 seconds, refreshes on focus, and receives same-browser feedback notifications. The anonymous feed includes status/mood/rating-only submissions as well as messages.
- Serialized feedback submission with session opening/closing and strengthened feedback request validation.
- Added editable student and class sections, same-subject section separation, bulk section enrollment, enrollment correction, and lesson titles. Existing records need section assignments through the admin UI.
- Added SET comparison bars, response counts, distribution donuts, empty states, and sample-size context. Teacher privacy thresholds and admin-only identified records are unchanged.
- Applied additive migration 004 after backing up the database. Verified the end-to-end workflow and charts in a guarded disposable QA database and browser, with no test feedback added to real records.

## Reference-style SET workspace and 15-question form

- Rebuilt student tasks, teacher results, and admin SET views around the supplied dark reference: task cards, search, real status filters, cycle selection, pagination, metadata tags, and a details sidebar.
- Added all 15 supplied statements, numbered 1–15, with the 5-to-1 manifestation scale and **D. Other Comments and Suggestions**.
- Students can reopen their own completed submissions in read-only mode. Other students’ answers remain inaccessible.
- Added questionnaire versioning. Existing eight-question responses, agreement scales, and scores remain intact; new cycles use the 15-question form.
- Added optional Asia/Manila start/due dates with server-side submission limits. Admins can manage actual branch, department, and schedule codes; missing values show **Not specified**.
- Teacher views remain anonymous and instructor-scoped; admin reviews retain identified student records. Visibility remains admin-controlled and was left hidden as before.
- Backed up the database and applied additive migration 003. Verified both versions, aggregation, submitted snapshots, role restrictions, privacy thresholds, date limits, read-only answers, search, filters, pagination, and responsive layouts. Test records were rolled back.

## Admin-controlled SET visibility

- Added **Turn on SET / Hide SET** to Admin → SET, with SET hidden by default.
- Student and teacher dashboard cards, navigation, and SET pages are unavailable while hidden. Stale student forms cannot submit after the feature is hidden.
- The submission path checks and locks the visibility setting to serialize submissions with changes to the admin switch.
- Existing evaluations, cycle status, result release, and live classroom feedback are preserved. Admin SET access remains available.
- Added the idempotent `002_set_visibility.sql` migration. Tested both states, blocked direct access, CSRF protection, and SET privacy rules, leaving the installed feature hidden.

## Student Evaluation of Teaching (SET)

- Added SET to the student dashboard and navigation, with enrolled-class selection, instructor-specific questionnaires, and completion tracking per cycle.
- Added eight required 1–5 teaching criteria plus optional strengths and suggestions. One submission per student/class/cycle is enforced in the database.
- Added teacher-only SET results scoped to the signed-in instructor, by class and cycle. Individual ratings and student identities are excluded; scores and unattributed comments require a closed, released cycle and at least three evaluations in the result group.
- Added admin SET cycle controls, teacher summaries, paginated identified submissions, and full admin-only evaluation details.
- Added `set_periods` and `teaching_evaluations` tables through an additive migration. Live classroom feedback remains anonymous, as requested, and its schema and stored responses are unchanged.
- Verified all three SET screens in the browser, student form responsiveness, database integration with rolled-back fixtures, and installed HTTP access/CSRF checks. See `SET-GUIDE.md` for usage and installation.

## Complete UI refresh

- Rebuilt the welcome page with a classroom check-in illustration and a clear introduction to the feedback flow.
- Unified student, teacher, and admin sign-in pages, with portal switching, persistent field labels, password visibility controls, and helpful error states.
- Updated the shared colors, typography, navigation, cards, tables, buttons, badges, and focus states. Admin screens retain a blue accent; teaching and student screens use green.
- Rebuilt student class cards, open/closed feedback states, and the anonymous feedback form with numbered sections, keyboard-accessible buttons, rating groups, and visible submission progress.
- Added duplicate-submit prevention, accessible selection states, success focus, and recovery after submission errors.
- Refined teacher class cards and live dashboard summaries, including named status counts and mobile metric grids.
- Updated all three admin management screens with labeled forms, searchable directories, record counts, and contained table scrolling on phones.
- Added asset versioning so browsers load updated styles and scripts.
- Verified welcome, login, student classes, closed feedback, admin overview, directory search, teacher overview, and live feedback in the browser. Checked phone layouts for sign-in, student classes, management forms, and live feedback. Open feedback markup was checked inside a rolled-back database transaction, without saving test class activity.
- Validation: all PHP syntax checks, `tests/dashboard.test.cjs`, `tests/student.test.cjs`, `tests/feedback-render.php`, and installed portal access smoke checks passed.

## Separate role dashboards

- Admin portal: `/admin/index.php` provides school-wide totals, account-management shortcuts, and class insights at `/admin/dashboard.php`.
- Teacher portal: `/teacher/index.php` provides a personal welcome, assigned classes, enrollment and response totals, and session controls. Live feedback remains at `/teacher/dashboard.php`.
- Admins and teachers use their own navigation and class-feedback routes. Teacher access is limited to assigned classes; admin pages require an admin login.
- Signing into another role clears the previous role's login privileges in the same browser session.
- Shared feedback rendering keeps both portals' live charts and error handling consistent.
- Verified both dashboards in the browser and ran `tests/portals-smoke.ps1` against the installed application for login, role access, class ownership, management pages, and CSRF rejection. All PHP syntax and dashboard JavaScript checks passed.

## Fresh database

Created a separate local `classpulse_revised` database and updated the revised app's configuration to use it. The original `classpulse` database is intact. The new database has 1 admin, 3 instructors, 4 classes, 20 students, and 80 enrollments. Sessions and feedback start empty. Starter passwords were verified against their stored hashes. `ClassPulse-database.sql` is a full importable copy including starter data. The earlier failed demo login described below applies to the original database.

The updated application is in `app/classpulse` and retains the PHP/MySQL setup of the original.

- Refreshed instructor/admin live dashboard with responsive spacing, green accents, clearer class selection, readable feedback cards, and useful empty states.
- Added session details, a manual refresh button, connection errors, and expired-login messaging.
- Closed sessions no longer display as live, and closing feedback is disabled when there is no open session.
- Empty sessions reset all dashboard values instead of leaving stale information visible.
- Starting another session asks before closing the current one.
- Invalid session actions are rejected; session changes from both instructor screens are serialized to prevent overlapping open sessions.
- Timeline buckets include the date so sessions spanning multiple days do not merge unrelated minutes.
- Participation handles zero enrollment and is capped at 100%.
- Strengthened missing/malformed CSRF token handling for dashboard forms.

## Validation

Run `node tests/dashboard.test.cjs` from this folder for dashboard behavior checks. PHP files were checked using PHP 8.2. The optional CLI-only `tests/database-smoke.php` checks the statistics endpoint against the configured database without changing application records.

The bundled demo instructor credentials were rejected by the existing local database, so a full authenticated browser walkthrough was not completed. Existing account passwords were not changed.

## Installation

Back up the current app, then replace its files with the contents of `app/classpulse` (or extract the updated ZIP into your web server's document folder). Keep your existing `config.php` if your database settings differ. No database migration is required for these changes. Open `/classpulse/teacher/login.php` and sign in with an existing instructor account.
