<?php require __DIR__ . '/../includes/bootstrap.php'; require_admin();
$t = in_array($_GET['t'] ?? '', ['instructors','classes','students']) ? $_GET['t'] : 'instructors'; $msg = ''; $ok = true;
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf(); $a = $_POST['act'] ?? ''; $v = fn($k) => trim($_POST[$k] ?? '');
  try {
    if (in_array($a, ['add_instructor','add_student']) && !cvsu_email($v('email'))) throw new Exception('Email must be a @cvsu.edu.ph address.');
    if (in_array($a, ['add_instructor','add_student','reset_instructor','reset_student']) && strlen($v('password')) < 8) throw new Exception('Password must be at least 8 characters.');
    $h = password_hash($v('password'), PASSWORD_DEFAULT);
    if ($a === 'add_instructor') db()->prepare('INSERT INTO teachers (name,email,password_hash) VALUES (?,?,?)')->execute([$v('name'),$v('email'),$h]);
    elseif ($a === 'reset_instructor') db()->prepare('UPDATE teachers SET password_hash=? WHERE id=?')->execute([$h,(int)$_POST['id']]);
    elseif ($a === 'add_class') db()->prepare('INSERT INTO classes (code,title,teacher_id) VALUES (?,?,?)')->execute([$v('code'),$v('title'),(int)$_POST['teacher_id']]);
    elseif ($a === 'assign') db()->prepare('UPDATE classes SET teacher_id=? WHERE id=?')->execute([(int)$_POST['teacher_id'],(int)$_POST['id']]);
    elseif ($a === 'add_student') db()->prepare('INSERT INTO students (student_number,email,name,password_hash) VALUES (?,?,?,?)')->execute([$v('number'),$v('email'),$v('name'),$h]);
    elseif ($a === 'reset_student') db()->prepare('UPDATE students SET password_hash=? WHERE id=?')->execute([$h,(int)$_POST['id']]);
    elseif ($a === 'enroll') { $st = db()->prepare('SELECT id FROM students WHERE student_number=?'); $st->execute([$v('number')]);
      if (!($sid = $st->fetchColumn())) throw new Exception('Student number not found.');
      db()->prepare('INSERT IGNORE INTO enrollments (student_id,class_id) VALUES (?,?)')->execute([$sid,(int)$_POST['class_id']]); }
    $msg = 'Saved.';
  } catch (Exception $x) { $ok = false; $msg = $x instanceof PDOException ? 'Could not save (duplicate or invalid data).' : $x->getMessage(); } }
$teachers = db()->query('SELECT id,name,email FROM teachers ORDER BY name')->fetchAll();
$classes = db()->query('SELECT c.*,t.name tname FROM classes c JOIN teachers t ON t.id=c.teacher_id ORDER BY code')->fetchAll();
$students = $t === 'students' ? db()->query('SELECT s.*,(SELECT COUNT(*) FROM enrollments e WHERE e.student_id=s.id) n FROM students s ORDER BY student_number LIMIT 300')->fetchAll() : [];
$tok = '<input type="hidden" name="csrf" value="'.csrf().'">';
$reset = fn($act,$id) => "<form method='post' class='reset-form'>$tok<input type='hidden' name='act' value='$act'><input type='hidden' name='id' value='$id'><input class='form-control form-control-sm' aria-label='New password for account $id' type='password' name='password' autocomplete='new-password' placeholder='New password' minlength='8' required><button class='btn btn-outline-dark btn-sm'>Reset</button></form>";
page_head(ucfirst($t).' · Management'); include __DIR__ . '/nav.php'; ?>
<main class="container portal admin-portal manage-portal py-4">
  <header class="portal-heading"><div class="dashboard-eyebrow">CAMPUS MANAGEMENT</div><h1><?= ucfirst($t) ?></h1><p><?= ['instructors'=>'Support your teaching team. Manage instructor accounts and access.','classes'=>'Bring the right students and instructors together in every class.','students'=>'Manage your student community and keep class enrollment organized.'][$t] ?></p></header>
  <ul class="nav nav-pills mb-3" aria-label="Management sections"><?php foreach (['instructors','classes','students'] as $x): ?><li class="nav-item"><a class="nav-link <?= $x==$t?'active bg-dark':'text-dark' ?>" <?= $x === $t ? 'aria-current="page"' : '' ?> href="?t=<?= $x ?>"><?= ucfirst($x) ?></a></li><?php endforeach; ?></ul>
  <?php if ($msg): ?><div class="alert alert-<?= $ok?'success':'danger' ?>" role="status"><?= e($msg) ?></div><?php endif; ?>

  <?php if ($t === 'instructors'): ?>
  <section class="card management-form mb-4"><div class="section-heading"><div><h2>Add an instructor</h2><p>Create an account for a new member of your teaching team.</p></div><span class="form-tag">New account</span></div>
    <form method="post" class="row g-2"><?= $tok ?><input type="hidden" name="act" value="add_instructor">
      <div class="col-md-3"><label for="instructor-name">Full name</label><input id="instructor-name" class="form-control" name="name" placeholder="e.g. Juan Dela Cruz" required></div>
      <div class="col-md-4"><label for="instructor-email">CvSU email</label><input id="instructor-email" class="form-control" type="email" name="email" placeholder="name@cvsu.edu.ph" required></div>
      <div class="col-md-3"><label for="instructor-password">Temporary password</label><input id="instructor-password" class="form-control" type="password" name="password" autocomplete="new-password" placeholder="At least 8 characters" minlength="8" required></div>
      <div class="col-md-2 d-flex align-items-end"><button class="btn btn-dark w-100">Add instructor</button></div></form></section>
  <section class="card records-card"><div class="records-heading"><div><h2>Teaching team <span class="record-count"><?= count($teachers) ?></span></h2><p>Account details and password resets.</p></div><label class="search-field"><span class="visually-hidden">Search instructors</span><input class="form-control" type="search" placeholder="Search name or email…" data-table-search="instructor-table"></label></div><div class="table-responsive"><table id="instructor-table" class="table align-middle"><thead><tr><th>Name</th><th>Email</th><th>Reset password</th></tr></thead><tbody>
    <?php foreach ($teachers as $r): ?><tr data-search-row="<?= e($r['name'].' '.$r['email']) ?>"><td><span class="person-name"><?= e($r['name']) ?></span></td><td><?= e($r['email']) ?></td><td><?= $reset('reset_instructor',$r['id']) ?></td></tr><?php endforeach; ?></tbody></table></div><p id="instructor-table-result" class="records-result" role="status"><?= count($teachers) ?> records shown</p></section>

  <?php elseif ($t === 'classes'): ?>
  <section class="card management-form mb-4"><div class="section-heading"><div><h2>Add a class</h2><p>Set up a course and assign its instructor.</p></div></div><form method="post" class="row g-3"><?= $tok ?><input type="hidden" name="act" value="add_class">
    <div class="col-md-2"><label for="class-code">Class code</label><input id="class-code" class="form-control" name="code" placeholder="ITD 103" required></div>
    <div class="col-md-5"><label for="class-title">Course title</label><input id="class-title" class="form-control" name="title" placeholder="e.g. Software Engineering" required></div>
    <div class="col-md-3"><label for="class-teacher">Instructor</label><select id="class-teacher" class="form-select" name="teacher_id" required><?php foreach ($teachers as $r): ?><option value="<?= $r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-dark w-100" <?= !$teachers ? 'disabled' : '' ?>>Add class</button></div></form></section>
  <section class="card management-form mb-4"><div class="section-heading"><div><h2>Enroll a student</h2><p>Connect an existing student account with a class.</p></div></div><form method="post" class="row g-3"><?= $tok ?><input type="hidden" name="act" value="enroll">
    <div class="col-md-4"><label for="enroll-number">Student number</label><input id="enroll-number" class="form-control" name="number" placeholder="e.g. 2023-0001" required></div>
    <div class="col-md-6"><label for="enroll-class">Class</label><select id="enroll-class" class="form-select" name="class_id" required><?php foreach ($classes as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['code'].' – '.$c['title']) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-dark w-100" <?= !$classes ? 'disabled' : '' ?>>Enroll student</button></div></form></section>
  <section class="card records-card"><div class="records-heading"><div><h2>Class directory <span class="record-count"><?= count($classes) ?></span></h2><p>Manage instructor assignments.</p></div><label class="search-field"><span class="visually-hidden">Search classes</span><input class="form-control" type="search" placeholder="Search classes…" data-table-search="class-table"></label></div><div class="table-responsive"><table id="class-table" class="table align-middle"><thead><tr><th>Class</th><th>Assigned instructor</th></tr></thead><tbody>
    <?php foreach ($classes as $c): ?><tr data-search-row="<?= e($c['code'].' '.$c['title'].' '.$c['tname']) ?>"><td><span class="class-code"><?= e($c['code']) ?></span><div class="mt-2 person-name"><?= e($c['title']) ?></div></td><td><form method="post" class="reset-form"><?= $tok ?><input type="hidden" name="act" value="assign"><input type="hidden" name="id" value="<?= $c['id'] ?>">
      <select class="form-select" aria-label="Instructor for <?= e($c['code']) ?>" name="teacher_id"><?php foreach ($teachers as $r): ?><option value="<?= $r['id'] ?>" <?= $r['id']==$c['teacher_id']?'selected':'' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select><button class="btn btn-outline-dark btn-sm">Save</button></form></td></tr><?php endforeach; ?></tbody></table></div><p id="class-table-result" class="records-result" role="status"><?= count($classes) ?> records shown</p></section>

  <?php else: ?>
  <section class="card management-form mb-4"><div class="section-heading"><div><h2>Add a student</h2><p>Create a student account, then enroll them from the Classes tab.</p></div><span class="form-tag">New account</span></div><form method="post" class="row g-3"><?= $tok ?><input type="hidden" name="act" value="add_student">
    <div class="col-md-2"><label for="student-number">Student number</label><input id="student-number" class="form-control" name="number" placeholder="2024-0001" required></div>
    <div class="col-md-3"><label for="student-name">Full name</label><input id="student-name" class="form-control" name="name" placeholder="Student’s full name" required></div>
    <div class="col-md-3"><label for="student-email">CvSU email</label><input id="student-email" class="form-control" type="email" name="email" placeholder="name@cvsu.edu.ph" required></div>
    <div class="col-md-2"><label for="student-password">Temporary password</label><input id="student-password" class="form-control" type="password" name="password" autocomplete="new-password" placeholder="8+ characters" minlength="8" required></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-dark w-100">Add student</button></div></form></section>
  <section class="card records-card"><div class="records-heading"><div><h2>Student directory <span class="record-count"><?= count($students) ?></span></h2><p><?= count($students) === 300 ? 'Showing the first 300 students. Search filters these records.' : 'Student accounts, enrollment totals, and password resets.' ?></p></div><label class="search-field"><span class="visually-hidden">Search students</span><input class="form-control" type="search" placeholder="Search number, name or email…" data-table-search="student-table"></label></div><div class="table-responsive"><table id="student-table" class="table align-middle"><thead><tr><th>Student no.</th><th>Name</th><th>Email</th><th>Classes</th><th>Reset password</th></tr></thead><tbody>
    <?php foreach ($students as $r): ?><tr data-search-row="<?= e($r['student_number'].' '.$r['name'].' '.$r['email']) ?>"><td class="student-number"><?= e($r['student_number']) ?></td><td class="person-name"><?= e($r['name']) ?></td><td><?= e($r['email']) ?></td><td><span class="record-count"><?= $r['n'] ?></span></td><td><?= $reset('reset_student',$r['id']) ?></td></tr><?php endforeach; ?></tbody></table></div><p id="student-table-result" class="records-result" role="status"><?= count($students) ?> records shown</p></section>
  <?php endif; ?>
</main><?php page_foot();
