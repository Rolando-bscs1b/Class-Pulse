const form = document.getElementById('fb');
if (form) {
  const state = { status: null, mood: null, cats: new Set() };
  const pick = (box, attr, key) => box.querySelectorAll(attr).forEach(el => el.onclick = () => {
    box.querySelectorAll(attr).forEach(x => { x.classList.remove('active'); x.setAttribute('aria-pressed','false'); }); el.classList.add('active'); el.setAttribute('aria-pressed','true'); state[key] = el.dataset.v; });
  pick(document.getElementById('status'), '.status-btn', 'status');
  pick(document.getElementById('mood'), '.mood-btn', 'mood');
  document.querySelectorAll('#cats .chip').forEach(c => c.onclick = () => {
    c.classList.toggle('active'); c.setAttribute('aria-pressed', String(c.classList.contains('active'))); c.classList.contains('active') ? state.cats.add(c.dataset.v) : state.cats.delete(c.dataset.v); });
  const msg = document.getElementById('message');
  msg.oninput = () => document.getElementById('count').textContent = msg.value.length + '/500';
  const err = document.getElementById('msg');
  const submit = form.querySelector('button[type="submit"]');
  let submitting = false;
  form.onsubmit = async e => {
    e.preventDefault(); err.classList.add('d-none');
    if (submitting) return;
    const ratings = {};
    ['clarity','pace','understanding','environment','participation'].forEach(k => {
      const r = form.querySelector(`input[name=r_${k}]:checked`); if (r) ratings[k] = +r.value; });
    const body = { csrf: document.getElementById('csrf').value, class_id: +form.dataset.class, status: state.status,
      mood: state.mood ? +state.mood : null, message: msg.value.trim(), ratings, categories: [...state.cats] };
    if (!body.status && !body.mood && !body.message && !Object.keys(ratings).length && !body.categories.length) {
      err.textContent = 'Please choose at least one response.'; err.classList.remove('d-none'); return; }
    submitting = true; submit.disabled = true; const submitText = submit.innerHTML; submit.textContent = 'Sending your feedback…'; form.setAttribute('aria-busy','true');
    try {
      const res = await fetch('api/submit.php', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || 'Failed');
      form.classList.add('d-none'); document.getElementById('done').classList.remove('d-none'); document.getElementById('done').focus();
    } catch (x) { err.textContent = x instanceof SyntaxError ? 'We couldn’t send your feedback. Please try again.' : x.message === 'Failed to fetch' ? 'Connection problem. Please try again.' : x.message; err.classList.remove('d-none'); }
    finally { submitting = false; submit.disabled = false; submit.innerHTML = submitText; form.removeAttribute('aria-busy'); }
  };
  document.getElementById('again').onclick = () => location.reload();
}
