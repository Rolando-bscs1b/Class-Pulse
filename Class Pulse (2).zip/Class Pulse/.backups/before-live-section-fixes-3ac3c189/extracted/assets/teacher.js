const cid = document.getElementById('dash').dataset.class, $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let fails = 0, delay = 3000, timer, busy = false, unauthorized = false;
const labels = {clarity:'Clarity',pace:'Pace',understanding:'Understanding',participation:'Participation',environment:'Classroom Environment'};
function render(d) {
  const session = d.session;
  $('session-title').textContent = !session ? 'Ready when you are' : session.ended_at ? 'Feedback session closed' : 'Feedback is open';
  $('session-detail').textContent = !session ? 'Start a session to collect anonymous feedback from your class.' : `Session #${session.id} · Started ${session.started_at}${session.ended_at ? ' · Closed ' + session.ended_at : ' · Students can send feedback now'}`;
  $('close-session').disabled = !session || !!session.ended_at;
  if (!session) d = {...d, mood:null, count:0, participation:0, status:{confused:0,following:0,bored:0},feed:[],eval:{},concerns:{},timeline:[]};
  $('mood').textContent = d.mood ?? '–'; $('count').textContent = d.count; $('part').textContent = d.participation + '%';
  ['confused','following','bored'].forEach(k => $('s_'+k).textContent = d.status[k]);
  const tot = d.status.confused + d.status.following + d.status.bored;
  $('alert').classList.toggle('d-none', !(tot >= 3 && d.status.confused / tot >= 0.4));
  $('feed').innerHTML = d.feed.length ? d.feed.map(f => `<article class="feedback-message small"><div class="d-flex justify-content-between text-muted mb-2"><b>Anonymous student</b><span>${Number(f.ago) < 1 ? 'Just now' : Number(f.ago) + ' min ago'}</span></div><div class="feedback-body">${esc(f.message)}</div></article>`).join('') : `<div class="dashboard-empty"><span class="empty-symbol" aria-hidden="true">○</span><strong>${!session ? 'A fresh start for your class' : 'No messages yet'}</strong><p>${!session ? 'Start a session to hear from your students.' : 'Anonymous written feedback will appear here.'}</p></div>`;
  $('eval').innerHTML = Object.keys(labels).map(k => { const v = d.eval[k]; return `<div class="mb-2"><div class="d-flex justify-content-between small"><span>${labels[k]}</span><b>${v ?? '–'}</b></div><div class="bar-bg"><div class="bar-fg" style="width:${(v||0)*20}%"></div></div></div>`; }).join('');
  $('concerns').innerHTML = Object.entries(d.concerns).map(([k,v]) => `<span class="chip">${esc(k)} <b>${v}</b></span>`).join('') || '<span class="text-muted small">None yet.</span>';
  const rows = {}; d.timeline.forEach(t => (rows[t.t] ??= {})[t.status] = +t.n);
  $('timeline').innerHTML = Object.entries(rows).map(([t,s]) => { const n = (s.confused||0)+(s.following||0)+(s.bored||0), seg = (k,c) => `<div class="tl-seg bg-${c}" style="width:${(s[k]||0)/n*100}%"></div>`;
    return `<div class="tl-row" aria-label="${esc(t)}: ${s.confused||0} confused, ${s.following||0} following, ${s.bored||0} bored"><span class="timeline-time">${esc(t)}</span><div class="d-flex flex-grow-1 timeline-track">${seg('confused','danger')}${seg('following','success')}${seg('bored','warning')}</div><span class="ms-2">${n}</span></div>`; }).join('') || '<span class="text-muted small">Status taps will appear here during a session.</span>';
  $('upd').textContent = d.server_time;
}
async function poll() {
  if (busy || unauthorized) return;
  clearTimeout(timer); busy = true; $('refresh').disabled = true;
  const dot = document.querySelector('.live-dot');
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const r = await fetch('../api/stats.php?class_id=' + encodeURIComponent(cid), {cache:'no-store', signal:controller.signal});
    if (r.status === 401 || r.status === 403) { unauthorized = true; throw new Error('access'); }
    if (!r.ok) throw new Error(r.status);
    const data = await r.json(); render(data); fails = 0; delay = 3000;
    dot.classList.toggle('off', !data.session || !!data.session.ended_at);
    $('connTxt').textContent = !data.session ? 'No session' : data.session.ended_at ? 'Session closed' : 'Live feedback';
    $('connection-error').classList.add('d-none');
  } catch (e) {
    fails++; delay = Math.min(15000, 3000 * fails); dot.classList.add('off');
    $('connTxt').textContent = unauthorized ? 'Access expired' : 'Reconnecting…';
    $('connection-error').textContent = unauthorized ? 'Your login has expired or you no longer have access. Return to your classes and sign in again.' : 'Unable to refresh feedback. Displayed data may be out of date. Retrying automatically.';
    $('connection-error').classList.remove('d-none');
  } finally { clearTimeout(timeout); busy = false; $('refresh').disabled = unauthorized; }
  if (!unauthorized) timer = setTimeout(poll, delay);
}
$('refresh').addEventListener('click', poll);
$('session-actions').addEventListener('submit', event => {
  if (event.submitter?.value === 'start' && !$('close-session').disabled && !window.confirm('Start a new session? This will close the current session and reset the dashboard to the new session.')) event.preventDefault();
});
poll();
