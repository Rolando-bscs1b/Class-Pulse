<?php require 'includes/set.php'; require_student();
$q = db()->prepare('SELECT c.*, t.name AS teacher, (SELECT COUNT(*) FROM sessions s WHERE s.class_id=c.id AND s.ended_at IS NULL) AS open_now
  FROM classes c JOIN enrollments e ON e.class_id=c.id JOIN teachers t ON t.id=c.teacher_id WHERE e.student_id=? ORDER BY c.code');
$q->execute([$_SESSION['student_id']]); $classes = $q->fetchAll();
$showSet=set_enabled(); $setCycle=$showSet ? set_period() : null;
$setCompleted=0;
if ($setCycle) { $q=db()->prepare('SELECT COUNT(*) FROM teaching_evaluations ev JOIN enrollments en ON en.class_id=ev.class_id AND en.student_id=ev.student_id WHERE ev.student_id=? AND ev.period_id=?'); $q->execute([$_SESSION['student_id'],$setCycle['id']]); $setCompleted=(int)$q->fetchColumn(); }
page_head('My Classes'); include __DIR__ . '/includes/student-nav.php'; ?>
<main class="container portal student-portal py-4">
  <header class="portal-heading"><div class="dashboard-eyebrow">YOUR STUDENT SPACE</div><h1>A little feedback goes a long way.</h1><p>Choose a class to check in, share a thought, or let your teacher know how the lesson is going.</p></header>
  <div class="student-summary"><div><span class="summary-number"><?= count($classes) ?></span><span>enrolled classes</span></div><div><span class="summary-number"><?= count(array_filter($classes, fn($class) => $class['open_now'] > 0)) ?></span><span>open for feedback</span></div><p><span aria-hidden="true">◈</span> Live classroom feedback is anonymous.</p></div>
  <?php if ($showSet): ?><section class="card set-dashboard-callout mb-4"><div><span class="dashboard-eyebrow">STUDENT EVALUATION OF TEACHING</span><h2>Your experience can improve teaching.</h2><p><?= $setCycle ? e($setCycle['title']).' · '.$setCompleted.' of '.count($classes).' completed'.($setCycle['is_open'] ? '' : ' · Cycle closed') : 'Your administrator will announce the next evaluation cycle.' ?></p><p class="set-small-note">SET is anonymous to teachers. Admins can identify submissions. Live classroom feedback stays anonymous.</p></div><a class="btn btn-dark" href="set.php"><?= $setCycle && $setCycle['is_open'] ? 'Complete SET →' : 'View SET →' ?></a></section><?php endif; ?>
  <div class="section-heading"><h2>My classes</h2><span>Find your next check-in</span></div><div class="student-class-grid">
  <?php foreach ($classes as $c): ?>
  <a href="feedback.php?class_id=<?= $c['id'] ?>" class="student-class-card card">
    <div class="d-flex justify-content-between align-items-center"><span class="class-code"><?= e($c['code']) ?></span><span class="badge <?= $c['open_now'] ? 'bg-success' : 'bg-secondary' ?>"><?= $c['open_now'] ? 'Feedback open' : 'Not open yet' ?></span></div>
    <h3><?= e($c['title']) ?></h3><p><?= e($c['teacher']) ?></p><div class="class-card-footer"><span><?= $c['open_now'] ? 'Share your feedback' : 'View class' ?></span><span aria-hidden="true">↗</span></div></a>
  <?php endforeach; if (!$classes): ?><div class="card empty-card"><span class="empty-symbol" aria-hidden="true">∿</span><h2>No classes yet</h2><p>Ask your instructor or administrator to enroll you in a class.</p></div><?php endif; ?>
</div></main><?php page_foot();
