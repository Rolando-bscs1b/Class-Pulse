<?php require __DIR__ . '/../includes/bootstrap.php'; require_student(true);
$in = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf'] ?? '', $in['csrf'] ?? '')) json_out(['error'=>'Invalid request'],403);
if (time() - ($_SESSION['last_submit'] ?? 0) < SUBMIT_COOLDOWN) json_out(['error'=>'Please wait a few seconds before sending again.'],429);
$cid = (int)($in['class_id'] ?? 0);
$chk = db()->prepare('SELECT 1 FROM enrollments WHERE student_id=? AND class_id=?'); $chk->execute([$_SESSION['student_id'], $cid]);
if (!$chk->fetch()) json_out(['error'=>'Not enrolled in this class'],403);
$s = db()->prepare('SELECT id FROM sessions WHERE class_id=? AND ended_at IS NULL'); $s->execute([$cid]);
if (!($sid = $s->fetchColumn())) json_out(['error'=>'Feedback is closed for this class'],409);
$status = in_array($in['status'] ?? null, ['confused','following','bored'], true) ? $in['status'] : null;
$mood = isset($in['mood']) && $in['mood'] >= 1 && $in['mood'] <= 5 ? (int)$in['mood'] : null;
$r = $in['ratings'] ?? []; $rv = fn($k) => isset($r[$k]) && $r[$k] >= 1 && $r[$k] <= 5 ? (int)$r[$k] : null;
$allowed = ['Too fast','Too slow','Need more examples','Need clarification','Good explanation','Good pace','More activities','Other'];
$cats = array_values(array_intersect($in['categories'] ?? [], $allowed));
$msg = mb_substr(trim((string)($in['message'] ?? '')), 0, 500) ?: null;
// Response row carries NO student identifier (anonymity).
db()->prepare('INSERT INTO responses (session_id,status,mood,message,clarity,pace,understanding,environment,participation,categories)
  VALUES (?,?,?,?,?,?,?,?,?,?)')->execute([$sid,$status,$mood,$msg,$rv('clarity'),$rv('pace'),$rv('understanding'),$rv('environment'),$rv('participation'),implode(',',$cats)]);
// Separate table only records THAT a student took part (for participation %), not what they said.
db()->prepare('INSERT IGNORE INTO participation (session_id,student_id) VALUES (?,?)')->execute([$sid,$_SESSION['student_id']]);
$_SESSION['last_submit'] = time();
json_out(['ok'=>true]);
