<?php
require_once __DIR__.'/bootstrap.php';
const SET_MIN_RESPONSES = 3;
require_once __DIR__.'/set-questionnaire.php';
function set_legacy_questions(): array {
    return [
        'preparation'=>['Preparation','The instructor comes prepared for class.'],
        'organization'=>['Organization','The instructor communicates clear learning goals.'],
        'clarity'=>['Clarity','The instructor explains concepts clearly.'],
        'examples'=>['Examples','The instructor uses examples that help me understand.'],
        'engagement'=>['Engagement','The instructor encourages students to participate.'],
        'support'=>['Support','The instructor responds constructively to questions.'],
        'fairness'=>['Fairness','The instructor evaluates student work fairly.'],
        'respect'=>['Respect','The instructor treats students respectfully.'],
    ];
}
function set_period(?int $id = null): ?array {
    if ($id !== null) { $q=db()->prepare('SELECT * FROM set_periods WHERE id=?'); $q->execute([$id]); }
    else $q=db()->query('SELECT * FROM set_periods ORDER BY is_open DESC,id DESC LIMIT 1');
    return $q->fetch() ?: null;
}
function set_validate(array $input,int $version=2): array {
    $ratings=[];
    foreach (set_questions($version) as $key=>$question) {
        $value=$input[$key] ?? null;
        if (!is_scalar($value) || !preg_match('/^[1-5]$/D', (string)$value)) throw new InvalidArgumentException('Please rate all '.count(set_questions($version)).' statements from 1 to 5.');
        $ratings[$key]=(int)$value;
    }
    $comments=[];
    foreach ($version===1 ? ['strengths','improvements'] : ['comments'] as $key) {
        if (isset($input[$key]) && !is_string($input[$key])) throw new InvalidArgumentException('Please enter valid text comments.');
        $value=trim($input[$key] ?? '');
        if (mb_strlen($value)>1500) throw new InvalidArgumentException('Each comment must be 1,500 characters or fewer.');
        $comments[$key]=$value;
    }
    return [$ratings,$comments];
}
function set_submit(int $studentId, int $classId, int $periodId, array $input): void {
    $ownsTransaction=!db()->inTransaction();
    if ($ownsTransaction) db()->beginTransaction(); else db()->exec('SAVEPOINT set_submission');
    try {
        $visibility=db()->query("SELECT enabled FROM feature_settings WHERE name='set' FOR UPDATE")->fetchColumn();
        if (!$visibility) throw new DomainException('SET is currently unavailable. Your answers have not been submitted.');
        $periodQuery=db()->prepare('SELECT * FROM set_periods WHERE id=? FOR UPDATE'); $periodQuery->execute([$periodId]); $period=$periodQuery->fetch();
        if (!set_accepting($period ?: null)) throw new DomainException('This evaluation cycle is closed or not yet available. Your answers have not been submitted.');
        $version=(int)$period['questionnaire_version']; [$ratings,$comments]=set_validate($input,$version);
        $class=db()->prepare('SELECT c.teacher_id FROM classes c JOIN enrollments en ON en.class_id=c.id WHERE c.id=? AND en.student_id=? FOR UPDATE'); $class->execute([$classId,$studentId]);
        $teacherId=$class->fetchColumn();
        if (!$teacherId) throw new DomainException('You can evaluate only classes you are enrolled in.');
        if (!is_scalar($input['teacher_id'] ?? null) || (string)$input['teacher_id'] !== (string)$teacherId) throw new DomainException('The assigned instructor changed. Reload this form before submitting.');
        if ($version===1) {
            $keys=implode(',',array_keys($ratings));
            db()->prepare("INSERT INTO teaching_evaluations (period_id,class_id,teacher_id,student_id,$keys,strengths,improvements,questionnaire_version) VALUES (".implode(',',array_fill(0,15,'?')).")")->execute([$periodId,$classId,$teacherId,$studentId,...array_values($ratings),...array_values($comments),1]);
        } else {
            db()->prepare('INSERT INTO teaching_evaluations (period_id,class_id,teacher_id,student_id,questionnaire_version,ratings_json,comments) VALUES (?,?,?,?,2,?,?)')->execute([$periodId,$classId,$teacherId,$studentId,json_encode($ratings,JSON_THROW_ON_ERROR),$comments['comments']]);
        }
        if ($ownsTransaction) db()->commit(); else db()->exec('RELEASE SAVEPOINT set_submission');
    } catch (Throwable $error) {
        if (db()->inTransaction()) { if ($ownsTransaction) db()->rollBack(); else { db()->exec('ROLLBACK TO SAVEPOINT set_submission'); db()->exec('RELEASE SAVEPOINT set_submission'); } }
        if ($error instanceof PDOException && (int)($error->errorInfo[1] ?? 0)===1062) throw new DomainException('You have already submitted SET for this class and cycle.');
        throw $error;
    }
}
function set_summary(int $teacherId, int $periodId, ?int $classId = null): array {
    if (!set_enabled()) return ['total'=>0,'visible'=>false,'scores'=>[],'overall'=>null,'comments'=>[]];
    $where='teacher_id=? AND period_id=?'; $params=[$teacherId,$periodId];
    if ($classId !== null) { $where.=' AND class_id=?'; $params[]=$classId; }
    $period=set_period($periodId);
    $q=db()->prepare("SELECT COUNT(*) FROM teaching_evaluations WHERE $where"); $q->execute($params); $total=(int)$q->fetchColumn();
    $visible=$period && !$period['is_open'] && $period['results_released'] && $total>=SET_MIN_RESPONSES;
    // Suppress scores and comments at the data boundary, not just in the template.
    $result=['total'=>$total,'visible'=>(bool)$visible,'scores'=>[],'overall'=>null,'comments'=>[]];
    if (!$visible) return $result;
    $columns=implode(',',array_keys(set_questions(1)));
    $q=db()->prepare("SELECT questionnaire_version,ratings_json,$columns,strengths,improvements,comments FROM teaching_evaluations WHERE $where"); $q->execute($params); $rows=$q->fetchAll();
    $totals=array_fill_keys(array_keys(set_questions((int)$period['questionnaire_version'])),0);
    foreach ($rows as $row) foreach (set_ratings($row) as $key=>$value) if (array_key_exists($key,$totals)) $totals[$key]+=(int)$value;
    foreach ($totals as $key=>$value) $result['scores'][$key]=round($value/$total,2);
    $result['overall']=round(array_sum($totals)/($total*count($totals)),2);
    // No student join, response IDs, exact timestamps, or submission order is exposed to teachers.
    $q=db()->prepare("SELECT strengths,improvements,comments FROM teaching_evaluations WHERE $where AND (strengths<>'' OR improvements<>'' OR comments<>'') ORDER BY comments,strengths,improvements"); $q->execute($params);
    $result['comments']=$q->fetchAll();
    return $result;
}
