<?php
require_once __DIR__.'/bootstrap.php';
const SET_MIN_RESPONSES = 3;
function set_questions(): array {
    return [
        'preparation'=>['Preparation','The instructor comes prepared for class.'],
        'organization'=>['Organization','The instructor communicates clear learning goals.'],
        'clarity'=>['Clarity','The instructor explains concepts clearly.'],
        'examples'=>['Examples','The instructor uses examples that help me understand.'],
        'engagement'=>['Engagement','The instructor encourages students to participate.'],
        'support'=>['Support','The instructor responds constructively to questions.'],
        'fairness'=>['Fairness','The instructor evaluates student work fairly.'],
        'respect'=>['Respect','The instructor treats students respectfully.'],
    ];
}
function set_period(?int $id = null): ?array {
    if ($id !== null) { $q=db()->prepare('SELECT id,title,is_open,results_released FROM set_periods WHERE id=?'); $q->execute([$id]); }
    else $q=db()->query('SELECT id,title,is_open,results_released FROM set_periods ORDER BY is_open DESC,id DESC LIMIT 1');
    return $q->fetch() ?: null;
}
function set_validate(array $input): array {
    $ratings=[];
    foreach (set_questions() as $key=>$question) {
        $value=$input[$key] ?? null;
        if (!is_scalar($value) || !preg_match('/^[1-5]$/D', (string)$value)) throw new InvalidArgumentException('Please rate all eight statements from 1 to 5.');
        $ratings[$key]=(int)$value;
    }
    $comments=[];
    foreach (['strengths','improvements'] as $key) {
        if (isset($input[$key]) && !is_string($input[$key])) throw new InvalidArgumentException('Please enter valid text comments.');
        $value=trim($input[$key] ?? '');
        if (mb_strlen($value)>1500) throw new InvalidArgumentException('Each comment must be 1,500 characters or fewer.');
        $comments[$key]=$value;
    }
    return [$ratings,$comments];
}
function set_submit(int $studentId, int $classId, int $periodId, array $input): void {
    [$ratings,$comments]=set_validate($input);
    $ownsTransaction=!db()->inTransaction();
    if ($ownsTransaction) db()->beginTransaction(); else db()->exec('SAVEPOINT set_submission');
    try {
        $period=db()->prepare('SELECT id FROM set_periods WHERE id=? AND is_open=1 FOR UPDATE'); $period->execute([$periodId]);
        if (!$period->fetch()) throw new DomainException('This evaluation cycle is closed. Your answers have not been submitted.');
        $class=db()->prepare('SELECT c.teacher_id FROM classes c JOIN enrollments en ON en.class_id=c.id WHERE c.id=? AND en.student_id=? FOR UPDATE'); $class->execute([$classId,$studentId]);
        $teacherId=$class->fetchColumn();
        if (!$teacherId) throw new DomainException('You can evaluate only classes you are enrolled in.');
        if (!is_scalar($input['teacher_id'] ?? null) || (string)$input['teacher_id'] !== (string)$teacherId) throw new DomainException('The assigned instructor changed. Reload this form before submitting.');
        $keys=implode(',',array_keys($ratings));
        db()->prepare("INSERT INTO teaching_evaluations (period_id,class_id,teacher_id,student_id,$keys,strengths,improvements) VALUES (".implode(',',array_fill(0,14,'?')).")")
            ->execute([$periodId,$classId,$teacherId,$studentId,...array_values($ratings),...array_values($comments)]);
        if ($ownsTransaction) db()->commit(); else db()->exec('RELEASE SAVEPOINT set_submission');
    } catch (Throwable $error) {
        if (db()->inTransaction()) { if ($ownsTransaction) db()->rollBack(); else { db()->exec('ROLLBACK TO SAVEPOINT set_submission'); db()->exec('RELEASE SAVEPOINT set_submission'); } }
        if ($error instanceof PDOException && (int)($error->errorInfo[1] ?? 0)===1062) throw new DomainException('You have already submitted SET for this class and cycle.');
        throw $error;
    }
}
function set_summary(int $teacherId, int $periodId, ?int $classId = null): array {
    $where='teacher_id=? AND period_id=?'; $params=[$teacherId,$periodId];
    if ($classId !== null) { $where.=' AND class_id=?'; $params[]=$classId; }
    $averages=implode(',',array_map(fn($key)=>"AVG($key) AS $key",array_keys(set_questions())));
    $q=db()->prepare("SELECT COUNT(*) AS total,$averages FROM teaching_evaluations WHERE $where"); $q->execute($params); $row=$q->fetch();
    $period=set_period($periodId);
    $visible=$period && !$period['is_open'] && $period['results_released'] && (int)$row['total']>=SET_MIN_RESPONSES;
    // Suppress scores and comments at the data boundary, not just in the template.
    $result=['total'=>(int)$row['total'],'visible'=>(bool)$visible,'scores'=>[],'overall'=>null,'comments'=>[]];
    if (!$visible) return $result;
    foreach (set_questions() as $key=>$question) $result['scores'][$key]=round((float)$row[$key],2);
    $result['overall']=round(array_sum($result['scores'])/count($result['scores']),2);
    // No student join, response IDs, exact timestamps, or submission order is exposed to teachers.
    $q=db()->prepare("SELECT strengths,improvements FROM teaching_evaluations WHERE $where AND (strengths<>'' OR improvements<>'') ORDER BY strengths,improvements"); $q->execute($params);
    $result['comments']=$q->fetchAll();
    return $result;
}
