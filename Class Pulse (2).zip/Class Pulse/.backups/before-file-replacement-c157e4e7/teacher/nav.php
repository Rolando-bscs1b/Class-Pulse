<nav class="portal-nav teacher-nav" aria-label="Teacher navigation">
  <a class="portal-brand" href="index.php"><span class="nav-symbol" aria-hidden="true">∿</span> ClassPulse <small>Teacher portal</small></a>
  <div class="portal-links"><a href="index.php" <?= basename($_SERVER['SCRIPT_NAME']) === 'index.php' ? 'aria-current="page"' : '' ?>>My dashboard</a><a href="dashboard.php" <?= basename($_SERVER['SCRIPT_NAME']) === 'dashboard.php' ? 'aria-current="page"' : '' ?>>Live feedback</a><a href="evaluations.php" <?= basename($_SERVER['SCRIPT_NAME']) === 'evaluations.php' ? 'aria-current="page"' : '' ?>>My SET results</a><a href="logout.php">Log out ↗</a></div>
</nav>
