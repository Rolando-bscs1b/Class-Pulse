<?php require __DIR__ . '/../includes/bootstrap.php'; require_teacher();
$tid = $_SESSION['teacher_id'];
$me = db()->prepare('SELECT name FROM teachers WHERE id=?'); $me->execute([$tid]); $name = $me->fetchColumn();
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf(); $cid = (int)($_POST['class_id'] ?? 0);
    if (!in_array($_POST['act'] ?? '', ['start', 'stop'], true)) { http_response_code(400); exit('Invalid session action.'); }
    $own = db()->prepare('SELECT 1 FROM classes WHERE id=? AND teacher_id=?'); $own->execute([$cid, $tid]);
    if ($own->fetch()) {
        db()->beginTransaction();
        $lock = db()->prepare('SELECT id FROM classes WHERE id=? FOR UPDATE'); $lock->execute([$cid]);
        db()->prepare('UPDATE sessions SET ended_at=NOW() WHERE class_id=? AND ended_at IS NULL')->execute([$cid]);
        if ($_POST['act'] === 'start') db()->prepare('INSERT INTO sessions (class_id) VALUES (?)')->execute([$cid]);
        db()->commit();
        if ($_POST['act'] === 'start') { header("Location: dashboard.php?class_id=$cid"); exit; }
    }
    header('Location: index.php'); exit; }
$q = db()->prepare("SELECT c.id,c.code,c.title,
  (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id) enrolled,
  (SELECT COUNT(*) FROM sessions s WHERE s.class_id=c.id) sessions_n,
  (SELECT COUNT(*) FROM sessions s WHERE s.class_id=c.id AND s.ended_at IS NULL) open_now,
  (SELECT COUNT(*) FROM responses r JOIN sessions s ON s.id=r.session_id WHERE s.class_id=c.id) resp,
  (SELECT ROUND(AVG(r.mood),1) FROM responses r JOIN sessions s ON s.id=r.session_id WHERE s.class_id=c.id) mood
  FROM classes c WHERE c.teacher_id=? ORDER BY c.code");
$q->execute([$tid]); $classes = $q->fetchAll();
page_head('Teacher Dashboard'); include __DIR__ . '/nav.php'; ?>
<main class="container portal teacher-portal py-4">
  <header class="portal-heading"><div class="dashboard-eyebrow">YOUR TEACHING SPACE</div><h1>Welcome, <?= e($name) ?>.</h1><p>Start a feedback session, hear from your students, and follow your classes.</p></header>
  <div class="session-banner mb-4"><div><strong><?= array_sum(array_column($classes, 'open_now')) ?> active feedback sessions</strong><div class="small text-muted">Choose one of your assigned classes below to see live feedback.</div></div></div>
  <section class="card set-dashboard-callout mb-4"><div><span class="dashboard-eyebrow">STUDENT EVALUATION OF TEACHING</span><h2>Explore your teaching evaluations.</h2><p>View anonymous class summaries and student perspectives when SET results are released.</p></div><a class="btn btn-outline-dark" href="evaluations.php">My SET results ↗</a></section>
  <div class="row g-3 mb-3 text-center">
    <?php $sum = fn($k) => array_sum(array_column($classes, $k)); foreach ([['My classes',count($classes)],['Class enrollments',$sum('enrolled')],['Sessions held',$sum('sessions_n')],['Responses',$sum('resp')]] as $x): ?>
    <div class="col-6 col-md-3"><div class="card p-3"><small><?= $x[0] ?></small><div class="display-6"><?= $x[1] ?></div></div></div><?php endforeach; ?>
  </div>
  <h2 class="h5 mb-3">My classes</h2><div class="row g-3">
    <?php foreach ($classes as $c): ?>
    <div class="col-md-6"><article class="card teacher-class-card h-100">
      <div class="d-flex justify-content-between align-items-center"><span class="class-code"><?= e($c['code']) ?></span><span class="badge <?= $c['open_now']?'bg-success':'bg-secondary' ?>"><?= $c['open_now']?'Feedback open':'Not open yet' ?></span></div>
      <h3><?= e($c['title']) ?></h3><div class="class-stat-grid"><div><strong><?= $c['enrolled'] ?></strong><span>Students</span></div><div><strong><?= $c['sessions_n'] ?></strong><span>Sessions</span></div><div><strong><?= $c['resp'] ?></strong><span>Responses</span></div><div><strong><?= $c['mood'] ?? '–' ?></strong><span>Avg. mood</span></div></div>
      <div class="d-flex flex-wrap gap-2 mt-3 teacher-class-actions"><a class="btn btn-outline-dark btn-sm" href="dashboard.php?class_id=<?= $c['id'] ?>">Live dashboard ↗</a>
        <form method="post" class="d-flex gap-2 ms-auto"><input type="hidden" name="csrf" value="<?= csrf() ?>"><input type="hidden" name="class_id" value="<?= $c['id'] ?>">
          <?php if ($c['open_now']): ?><button name="act" value="stop" class="btn btn-secondary btn-sm">Close feedback</button>
          <?php else: ?><button name="act" value="start" class="btn btn-dark btn-sm">Start session</button><?php endif; ?></form></div>
    </article></div><?php endforeach; if (!$classes) echo '<div class="col-12"><div class="card empty-card"><span class="empty-symbol" aria-hidden="true">∿</span><h2>Your classes will appear here.</h2><p>No classes are assigned yet. Ask your administrator to add your classes.</p></div></div>'; ?>
  </div>
</main><?php page_foot();
