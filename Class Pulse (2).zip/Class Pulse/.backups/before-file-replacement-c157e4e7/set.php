<?php
require_once __DIR__.'/includes/set.php'; require_student();
$studentId=(int)$_SESSION['student_id'];
$period=set_period(); $error=''; $success=isset($_GET['submitted']);
$classId=(int)($_GET['class_id'] ?? 0);
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    try {
        set_submit($studentId,$classId,(int)($_POST['period_id'] ?? 0),$_POST);
        header('Location: set.php?submitted=1'); exit;
    } catch (InvalidArgumentException|DomainException $exception) { $error=$exception->getMessage(); }
    catch (PDOException $exception) { error_log('SET submission database error: '.$exception->getCode()); $error='Your evaluation could not be saved. Please try again.'; }
}
$q=db()->prepare('SELECT c.id,c.code,c.title,c.teacher_id,t.name teacher,ev.id evaluation_id FROM enrollments en JOIN classes c ON c.id=en.class_id JOIN teachers t ON t.id=c.teacher_id LEFT JOIN teaching_evaluations ev ON ev.class_id=c.id AND ev.student_id=en.student_id AND ev.period_id=? WHERE en.student_id=? ORDER BY c.code');
$q->execute([$period['id'] ?? 0,$studentId]); $classes=$q->fetchAll();
$current=null; foreach ($classes as $class) if ((int)$class['id']===$classId) $current=$class;
if ($classId && !$current) { http_response_code(404); }
page_head('Student Evaluation of Teaching'); include __DIR__.'/includes/student-nav.php'; ?>
<main class="container portal student-portal py-4">
  <header class="portal-heading"><div class="dashboard-eyebrow">STUDENT EVALUATION OF TEACHING</div><h1>Help shape better teaching.</h1><p>Reflect on your instructor’s teaching throughout the course. SET is separate from live classroom feedback.</p></header>
  <div class="set-privacy" role="note"><span aria-hidden="true">◈</span><div><strong>Anonymous to teachers. Identifiable to administrators.</strong><p>Teachers receive combined ratings and unattributed comments after results are released, with at least <?= SET_MIN_RESPONSES ?> evaluations in a result group. Admins can see your name, student number, ratings, and comments. Please leave personal details out of your comments.</p></div></div>
  <?php if ($success): ?><div class="alert alert-success" role="status">Your SET has been submitted. Thank you for sharing your perspective.</div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger" role="alert"><?= e($error) ?></div><?php endif; ?>
  <?php if (!$period): ?><div class="card empty-card"><h2>No evaluation cycle yet</h2><p>Your administrator will open SET when it is time to evaluate your instructors.</p></div>
  <?php elseif ($classId && !$current): ?><div class="card empty-card"><h2>Class not found</h2><p>You can evaluate only your enrolled classes.</p><a href="set.php" class="btn btn-dark">Back to SET</a></div>
  <?php elseif ($current && $period['is_open'] && !$current['evaluation_id']): ?>
    <div class="set-form-layout"><aside class="card set-instructor"><a class="back-link" href="set.php">← All evaluations</a><span class="class-code"><?= e($current['code']) ?></span><h2><?= e($current['teacher']) ?></h2><p><?= e($current['title']) ?></p><hr><strong><?= e($period['title']) ?></strong><p>One submission per class in this cycle. Submitted answers cannot be edited.</p></aside>
    <form method="post" class="set-questionnaire" id="set-form"><input type="hidden" name="csrf" value="<?= csrf() ?>"><input type="hidden" name="period_id" value="<?= $period['id'] ?>"><input type="hidden" name="teacher_id" value="<?= $current['teacher_id'] ?>">
      <section class="feedback-section"><h2 class="h5">Your experience with this instructor</h2><p class="text-muted small" id="set-scale">Rate all eight statements. 1 = strongly disagree, 2 = disagree, 3 = neutral, 4 = agree, 5 = strongly agree.</p>
      <?php foreach (set_questions() as $key=>[$label,$statement]): ?><fieldset class="rate" aria-describedby="set-scale"><legend><?= e($statement) ?></legend><div class="rating-options"><?php for ($rating=1;$rating<=5;$rating++): ?><input type="radio" name="<?= $key ?>" id="set-<?= $key.$rating ?>" value="<?= $rating ?>" <?= is_scalar($_POST[$key] ?? null) && (string)$_POST[$key]===(string)$rating ? 'checked' : '' ?> required><label for="set-<?= $key.$rating ?>"><span class="visually-hidden"><?= e($label) ?>: </span><?= $rating ?></label><?php endfor; ?></div></fieldset><?php endforeach; ?></section>
      <section class="feedback-section"><h2 class="h5">Anything else you’d like to share?</h2><label for="set-strengths" class="mb-2 mt-3">What does this instructor do well? <span class="text-muted">(optional)</span></label><textarea id="set-strengths" name="strengths" class="form-control" rows="4" maxlength="1500" placeholder="Share helpful teaching practices…"><?= e(is_string($_POST['strengths'] ?? null) ? $_POST['strengths'] : '') ?></textarea>
      <label for="set-improvements" class="mb-2 mt-4">What could be improved? <span class="text-muted">(optional)</span></label><textarea id="set-improvements" name="improvements" class="form-control" rows="4" maxlength="1500" placeholder="Share constructive suggestions…"><?= e(is_string($_POST['improvements'] ?? null) ? $_POST['improvements'] : '') ?></textarea><p class="small text-muted mt-3 mb-0">Up to 1,500 characters each. Comments are shared with your teacher without your identity. Admins can identify your submission.</p></section>
      <button type="submit" class="btn btn-dark w-100 py-3">Submit teaching evaluation →</button>
    </form></div>
  <?php else: ?><div class="section-heading"><div><h2><?= e($period['title']) ?></h2><p><?= $period['is_open'] ? 'Evaluate each instructor for your enrolled classes.' : 'This cycle is closed. You can view your completion status below.' ?></p></div><span class="badge <?= $period['is_open'] ? 'bg-success' : 'bg-secondary' ?>"><?= $period['is_open'] ? 'Open for SET' : 'Closed' ?></span></div><div class="student-class-grid">
    <?php foreach ($classes as $class): ?><article class="card student-class-card"><div class="d-flex justify-content-between"><span class="class-code"><?= e($class['code']) ?></span><span class="badge <?= $class['evaluation_id'] ? 'bg-success' : 'bg-secondary' ?>"><?= $class['evaluation_id'] ? 'Submitted' : 'Not submitted' ?></span></div><h3><?= e($class['teacher']) ?></h3><p><?= e($class['title']) ?></p><div class="class-card-footer"><?php if ($period['is_open'] && !$class['evaluation_id']): ?><a href="set.php?class_id=<?= $class['id'] ?>">Evaluate instructor ↗</a><?php else: ?><span><?= $class['evaluation_id'] ? 'Thank you for completing SET.' : 'Submissions are closed.' ?></span><?php endif; ?></div></article><?php endforeach; ?>
    <?php if (!$classes): ?><div class="card empty-card"><h2>No enrolled classes</h2><p>Ask your administrator about class enrollment.</p></div><?php endif; ?></div>
  <?php endif; ?>
</main><?php page_foot();
