# ClassPulse (PHP + MySQL + Bootstrap + JavaScript)
SET is available from the student dashboard. Students submit one evaluation per enrolled class per cycle. Teachers see only their own anonymous class summaries after the admin closes and releases a cycle, with a minimum of three evaluations per result group. Admins can inspect student identities and full SET submissions. Live classroom feedback remains anonymous to everyone. SET uses eight starter teaching criteria and optional comments.
For existing databases, import `migrations/001_set.sql` into the configured database before installing the updated application. Fresh installs using `setup.php` include the SET schema and an open starter cycle.
Includes a complete responsive UI refresh for the welcome page, all sign-in pages, student classes and feedback, teacher dashboards, and admin management. Admin directories support local search; feedback controls work with keyboard navigation. No database migration is needed for the UI update.
The revised app uses the separate `classpulse_revised` database. Its starter data includes 1 admin, 3 instructors, 4 classes, and 20 students. Feedback starts empty.
Admin portal: `/classpulse/admin/login.php` → school overview and management. Teacher portal: `/classpulse/teacher/login.php` → assigned classes and live feedback. If installed in a parent folder, include that folder before `/classpulse` in these URLs. Each portal has its own dashboard pages and access checks.
1. Copy `classpulse` to `htdocs`. Edit `config.php` if needed.
2. Open `/classpulse/setup.php` once (creates/upgrades DB + demo data), then delete it.
3. Logins (change all demo passwords):
   - Student: 2023-0001 or student1@cvsu.edu.ph / student123
   - Instructor: santos@cvsu.edu.ph / teacher123  -> /teacher/login.php
   - Admin: admin@cvsu.edu.ph / admin123 -> /admin/login.php
Admin manages instructors, classes, students, enrollment, and starts/closes feedback sessions. Instructors have their own overview and start/close sessions for their own classes.
Responses store no student ID; `participation` records only who took part.
