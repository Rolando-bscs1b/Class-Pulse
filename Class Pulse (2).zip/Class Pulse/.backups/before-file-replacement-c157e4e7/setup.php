<?php // Run ONCE (http://localhost/classpulse/setup.php), then DELETE this file. Safe to re-run for upgrades.
require_once __DIR__ . '/config.php';
$pdo = new PDO('mysql:host='.DB_HOST.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
if (!preg_match('/^[A-Za-z0-9_]+$/', DB_NAME)) throw new RuntimeException('Invalid database name.');
$pdo->exec('CREATE DATABASE IF NOT EXISTS `'.DB_NAME.'` CHARACTER SET utf8mb4');
$pdo->exec('USE `'.DB_NAME.'`');
foreach (array_filter(array_map('trim', explode(';', file_get_contents(__DIR__ . '/database.sql')))) as $stmt) {
  // The configured database takes precedence over the standalone SQL import name.
  if (preg_match('/^(CREATE DATABASE|USE)\b/i', $stmt)) continue;
  $pdo->exec($stmt);
}
// Upgrade older installs
foreach (['name VARCHAR(100) NULL','password_hash VARCHAR(255) NULL'] as $col) {
  $n = explode(' ', $col)[0];
  if (!$pdo->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema='".DB_NAME."' AND table_name='students' AND column_name='$n'")->fetchColumn())
    $pdo->exec("ALTER TABLE students ADD COLUMN $col");
}
if (!$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn())
  $pdo->prepare('INSERT INTO admins (name,email,password_hash) VALUES (?,?,?)')->execute(['System Admin','admin@cvsu.edu.ph',password_hash('admin123',PASSWORD_DEFAULT)]);
if (!$pdo->query('SELECT COUNT(*) FROM teachers')->fetchColumn()) {
  $h = password_hash('teacher123', PASSWORD_DEFAULT);
  foreach ([['Prof. Santos','santos@cvsu.edu.ph'],['Prof. Reyes','reyes@cvsu.edu.ph'],['Prof. Dela Cruz','delacruz@cvsu.edu.ph']] as $t)
    $pdo->prepare('INSERT INTO teachers (name,email,password_hash) VALUES (?,?,?)')->execute([$t[0],$t[1],$h]);
  foreach ([['ITD 101','Web Development',1],['FASD 101','Computer Fundamentals',2],['ITD 102','Database Systems',3],['FASD 102','Mobile App Development',1]] as $c)
    $pdo->prepare('INSERT INTO classes (code,title,teacher_id) VALUES (?,?,?)')->execute($c);
  $sh = password_hash('student123', PASSWORD_DEFAULT);
  for ($i=1;$i<=20;$i++) { $pdo->prepare('INSERT INTO students (student_number,email,name,password_hash) VALUES (?,?,?,?)')->execute([sprintf('2023-%04d',$i), "student$i@cvsu.edu.ph", "Student $i", $sh]);
    for ($c=1;$c<=4;$c++) $pdo->exec("INSERT INTO enrollments (student_id,class_id) VALUES ($i,$c)"); }
}
$pdo->prepare('UPDATE students SET password_hash=? WHERE password_hash IS NULL')->execute([password_hash('student123',PASSWORD_DEFAULT)]);
echo 'Setup complete. <b>Delete setup.php now.</b> <a href="index.php">Open app</a>';
