-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: classpulse_revised
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `classpulse_revised`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `classpulse_revised` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `classpulse_revised`;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'System Admin','admin@cvsu.edu.ph','$2y$10$TZQHy5JUyuqOYJacyJPBK.GCcGfSWpBKkcVn/J2zEYXNki.z9yJU6');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `title` varchar(120) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `teacher_id` (`teacher_id`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES (1,'ITD 101','Web Development',1),(2,'FASD 101','Computer Fundamentals',2),(3,'ITD 102','Database Systems',3),(4,'FASD 102','Mobile App Development',1);
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollments` (
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  PRIMARY KEY (`student_id`,`class_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES (1,1),(1,2),(1,3),(1,4),(2,1),(2,2),(2,3),(2,4),(3,1),(3,2),(3,3),(3,4),(4,1),(4,2),(4,3),(4,4),(5,1),(5,2),(5,3),(5,4),(6,1),(6,2),(6,3),(6,4),(7,1),(7,2),(7,3),(7,4),(8,1),(8,2),(8,3),(8,4),(9,1),(9,2),(9,3),(9,4),(10,1),(10,2),(10,3),(10,4),(11,1),(11,2),(11,3),(11,4),(12,1),(12,2),(12,3),(12,4),(13,1),(13,2),(13,3),(13,4),(14,1),(14,2),(14,3),(14,4),(15,1),(15,2),(15,3),(15,4),(16,1),(16,2),(16,3),(16,4),(17,1),(17,2),(17,3),(17,4),(18,1),(18,2),(18,3),(18,4),(19,1),(19,2),(19,3),(19,4),(20,1),(20,2),(20,3),(20,4);
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feature_settings`
--

DROP TABLE IF EXISTS `feature_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feature_settings` (
  `name` varchar(64) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_settings`
--

LOCK TABLES `feature_settings` WRITE;
/*!40000 ALTER TABLE `feature_settings` DISABLE KEYS */;
INSERT INTO `feature_settings` VALUES ('set',0);
/*!40000 ALTER TABLE `feature_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participation`
--

DROP TABLE IF EXISTS `participation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participation` (
  `session_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  PRIMARY KEY (`session_id`,`student_id`),
  CONSTRAINT `participation_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participation`
--

LOCK TABLES `participation` WRITE;
/*!40000 ALTER TABLE `participation` DISABLE KEYS */;
/*!40000 ALTER TABLE `participation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `responses`
--

DROP TABLE IF EXISTS `responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `status` enum('confused','following','bored') DEFAULT NULL,
  `mood` tinyint(4) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `clarity` tinyint(4) DEFAULT NULL,
  `pace` tinyint(4) DEFAULT NULL,
  `understanding` tinyint(4) DEFAULT NULL,
  `environment` tinyint(4) DEFAULT NULL,
  `participation` tinyint(4) DEFAULT NULL,
  `categories` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`,`created_at`),
  CONSTRAINT `responses_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responses`
--

LOCK TABLES `responses` WRITE;
/*!40000 ALTER TABLE `responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `started_at` datetime DEFAULT current_timestamp(),
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`,`ended_at`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (2,4,'2026-11-06 21:20:46','2026-11-06 21:20:50'),(3,4,'2026-11-06 21:20:50',NULL);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `set_periods`
--

DROP TABLE IF EXISTS `set_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `set_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `is_open` tinyint(4) NOT NULL DEFAULT 1,
  `results_released` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `open_slot` tinyint(4) GENERATED ALWAYS AS (case when `is_open` = 1 then 1 else NULL end) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_open_set_period` (`open_slot`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `set_periods`
--

LOCK TABLES `set_periods` WRITE;
/*!40000 ALTER TABLE `set_periods` DISABLE KEYS */;
INSERT INTO `set_periods` VALUES (1,'Current SET cycle',0,1,'2026-11-06 20:46:01',NULL);
/*!40000 ALTER TABLE `set_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_number` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_number` (`student_number`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'2023-0001','student1@cvsu.edu.ph','Student 1','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(2,'2023-0002','student2@cvsu.edu.ph','Student 2','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(3,'2023-0003','student3@cvsu.edu.ph','Student 3','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(4,'2023-0004','student4@cvsu.edu.ph','Student 4','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(5,'2023-0005','student5@cvsu.edu.ph','Student 5','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(6,'2023-0006','student6@cvsu.edu.ph','Student 6','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(7,'2023-0007','student7@cvsu.edu.ph','Student 7','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(8,'2023-0008','student8@cvsu.edu.ph','Student 8','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(9,'2023-0009','student9@cvsu.edu.ph','Student 9','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(10,'2023-0010','student10@cvsu.edu.ph','Student 10','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(11,'2023-0011','student11@cvsu.edu.ph','Student 11','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(12,'2023-0012','student12@cvsu.edu.ph','Student 12','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(13,'2023-0013','student13@cvsu.edu.ph','Student 13','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(14,'2023-0014','student14@cvsu.edu.ph','Student 14','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(15,'2023-0015','student15@cvsu.edu.ph','Student 15','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(16,'2023-0016','student16@cvsu.edu.ph','Student 16','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(17,'2023-0017','student17@cvsu.edu.ph','Student 17','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(18,'2023-0018','student18@cvsu.edu.ph','Student 18','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(19,'2023-0019','student19@cvsu.edu.ph','Student 19','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi'),(20,'2023-0020','student20@cvsu.edu.ph','Student 20','$2y$10$OCkd4fhsJQOUpNbwm/1xZexRdCAyozuYYJT8GqZaY7BS50ovGLJpi');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,'Prof. Santos','santos@cvsu.edu.ph','$2y$10$IGY32pCaAjX/Ei28ZHLECONkGT6DqeQkl9K/4C.NVkjcb4EyRlbBW'),(2,'Prof. Reyes','reyes@cvsu.edu.ph','$2y$10$IGY32pCaAjX/Ei28ZHLECONkGT6DqeQkl9K/4C.NVkjcb4EyRlbBW'),(3,'Prof. Dela Cruz','delacruz@cvsu.edu.ph','$2y$10$IGY32pCaAjX/Ei28ZHLECONkGT6DqeQkl9K/4C.NVkjcb4EyRlbBW');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaching_evaluations`
--

DROP TABLE IF EXISTS `teaching_evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teaching_evaluations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `preparation` tinyint(4) NOT NULL CHECK (`preparation` between 1 and 5),
  `organization` tinyint(4) NOT NULL CHECK (`organization` between 1 and 5),
  `clarity` tinyint(4) NOT NULL CHECK (`clarity` between 1 and 5),
  `examples` tinyint(4) NOT NULL CHECK (`examples` between 1 and 5),
  `engagement` tinyint(4) NOT NULL CHECK (`engagement` between 1 and 5),
  `support` tinyint(4) NOT NULL CHECK (`support` between 1 and 5),
  `fairness` tinyint(4) NOT NULL CHECK (`fairness` between 1 and 5),
  `respect` tinyint(4) NOT NULL CHECK (`respect` between 1 and 5),
  `strengths` varchar(1500) NOT NULL DEFAULT '',
  `improvements` varchar(1500) NOT NULL DEFAULT '',
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_set_per_class_cycle` (`period_id`,`class_id`,`student_id`),
  KEY `set_teacher_results` (`teacher_id`,`period_id`,`class_id`),
  KEY `class_id` (`class_id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `teaching_evaluations_ibfk_1` FOREIGN KEY (`period_id`) REFERENCES `set_periods` (`id`),
  CONSTRAINT `teaching_evaluations_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`),
  CONSTRAINT `teaching_evaluations_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`),
  CONSTRAINT `teaching_evaluations_ibfk_4` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaching_evaluations`
--

LOCK TABLES `teaching_evaluations` WRITE;
/*!40000 ALTER TABLE `teaching_evaluations` DISABLE KEYS */;
INSERT INTO `teaching_evaluations` VALUES (9,1,2,2,1,5,3,3,4,5,3,3,3,'hes good','speech','2026-11-06 20:55:58'),(10,1,4,1,1,5,5,5,5,5,5,5,5,'verygood','words of choice','2026-11-06 20:57:21');
/*!40000 ALTER TABLE `teaching_evaluations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-13 19:05:28
