<?php require __DIR__ . '/../includes/bootstrap.php'; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf();
    $s = db()->prepare('SELECT * FROM teachers WHERE email=?'); $s->execute([trim($_POST['email'] ?? '')]); $t = $s->fetch();
    if ($t && password_verify($_POST['password'] ?? '', $t['password_hash'])) { session_regenerate_id(true); unset($_SESSION['admin_id'], $_SESSION['student_id']); $_SESSION['teacher_id'] = (int)$t['id']; header('Location: index.php'); exit; }
    $err = 'Invalid email or password.'; }
page_head('Instructor Login'); $authRole = 'teacher'; require __DIR__ . '/../includes/auth-view.php'; page_foot();
