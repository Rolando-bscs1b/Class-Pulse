<?php
require __DIR__ . '/../includes/bootstrap.php';
require_teacher();
$isAdmin = false;
require __DIR__ . '/../includes/class-dashboard.php';
