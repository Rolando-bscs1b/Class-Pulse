<?php
$authRole = $authRole ?? 'student';
$isStudentLogin = $authRole === 'student';
$roleName = ucfirst($authRole);
?>
<main class="auth-shell <?= $authRole === 'admin' ? 'theme-admin' : '' ?>">
  <section class="auth-story">
    <a class="wordmark" href="<?= e(app_url()) ?>"><span class="brand-icon" aria-hidden="true">∿</span> ClassPulse</a>
    <div class="auth-story-content"><span class="eyebrow">A LITTLE FEEDBACK. A BETTER CLASS.</span><h1>Great classes<br>start with<br><em>listening.</em></h1><p>A space for honest feedback, meaningful connections, and moments of understanding.</p>
      <div class="pulse-art" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
      <div class="story-note"><span class="note-dot"></span>Small signals. Meaningful change.</div>
    </div><span class="auth-campus">Cavite State University · Naic Campus</span>
  </section>
  <section class="auth-panel"><div class="auth-form-wrap">
    <a class="back-link" href="<?= e(app_url()) ?>">← Back to home</a>
    <div class="role-switch" aria-label="Choose your portal"><?php foreach (['student'=>'login.php','teacher'=>'teacher/login.php','admin'=>'admin/login.php'] as $role=>$path): ?><a href="<?= e(app_url($path)) ?>" class="<?= $authRole === $role ? 'selected' : '' ?>" <?= $authRole === $role ? 'aria-current="page"' : '' ?>><?= ucfirst($role) ?></a><?php endforeach; ?></div>
    <span class="eyebrow"><?= e(strtoupper($roleName)) ?> PORTAL</span><h2>Welcome back.</h2><p class="auth-description"><?= $isStudentLogin ? 'Your perspective makes a difference. Sign in to share it.' : ($authRole === 'admin' ? 'Sign in to manage your campus community.' : 'Sign in to see how your students are doing.') ?></p>
    <?php if ($err): ?><div class="alert alert-danger" role="alert"><?= e($err) ?></div><?php endif; ?>
    <form method="post" class="auth-form"><input type="hidden" name="csrf" value="<?= csrf() ?>">
      <label for="login-identity"><?= $isStudentLogin ? 'Student number or CvSU email' : 'CvSU email address' ?></label>
      <input id="login-identity" class="form-control" type="<?= $isStudentLogin ? 'text' : 'email' ?>" name="<?= $isStudentLogin ? 'identifier' : 'email' ?>" autocomplete="username" placeholder="<?= $isStudentLogin ? 'e.g. 2023-0001' : 'you@cvsu.edu.ph' ?>" value="<?= e($_POST[$isStudentLogin ? 'identifier' : 'email'] ?? '') ?>" required>
      <label for="login-password">Password</label><div class="password-field"><input id="login-password" class="form-control" type="password" name="password" autocomplete="current-password" placeholder="Enter your password" required><button type="button" class="password-toggle" data-password="login-password" aria-label="Show password" aria-pressed="false">Show</button></div>
      <button class="btn btn-dark w-100 auth-submit">Sign in <span aria-hidden="true">→</span></button>
    </form>
    <p class="help-note">Need access or forgot your password?<br>Contact <?= $authRole === 'admin' ? 'your system administrator' : 'your instructor or administrator' ?>.</p>
    <div class="privacy-note"><span aria-hidden="true">◈</span><span>Live classroom feedback stays anonymous.<?php if (set_enabled()): ?><br>SET is anonymous to teachers; admins can identify SET submissions.<?php endif; ?></span></div>
  </div></section>
</main>
