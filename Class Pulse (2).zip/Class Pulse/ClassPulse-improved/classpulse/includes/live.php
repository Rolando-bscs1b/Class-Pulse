<?php
require_once __DIR__.'/bootstrap.php';
function student_live_state(int $studentId,int $classId): ?array {
    $q=db()->prepare('SELECT c.id,c.code,c.title,c.section_name FROM classes c JOIN enrollments en ON en.class_id=c.id WHERE en.student_id=? AND c.id=?'); $q->execute([$studentId,$classId]); $class=$q->fetch();
    if (!$class) return null;
    $q=db()->prepare('SELECT id,lesson_title,started_at,ended_at FROM sessions WHERE class_id=? ORDER BY id DESC LIMIT 1'); $q->execute([$classId]); $session=$q->fetch() ?: null;
    return ['class'=>$class,'session'=>$session,'open'=>$session && $session['ended_at']===null];
}
function save_live_feedback(int $studentId,array $input): int {
    $classId=filter_var($input['class_id'] ?? null,FILTER_VALIDATE_INT);
    $expectedSession=filter_var($input['session_id'] ?? null,FILTER_VALIDATE_INT);
    if (!$classId || !$expectedSession) throw new InvalidArgumentException('Reload the class feedback page before submitting.');
    $status=$input['status'] ?? null;
    if ($status!==null && !in_array($status,['confused','following','bored'],true)) throw new InvalidArgumentException('Choose a valid status.');
    $rating=function($value) { if ($value===null || $value==='') return null; if (!is_scalar($value) || !preg_match('/^[1-5]$/D',(string)$value)) throw new InvalidArgumentException('Ratings must be whole numbers from 1 to 5.'); return (int)$value; };
    $mood=$rating($input['mood'] ?? null); $ratings=$input['ratings'] ?? [];
    if (!is_array($ratings)) throw new InvalidArgumentException('Invalid ratings.');
    $values=[]; foreach (['clarity','pace','understanding','environment','participation'] as $key) $values[]=$rating($ratings[$key] ?? null);
    $categories=$input['categories'] ?? []; if (!is_array($categories)) throw new InvalidArgumentException('Invalid categories.');
    $allowed=['Too fast','Too slow','Need more examples','Need clarification','Good explanation','Good pace','More activities','Other'];
    $categories=array_values(array_unique(array_filter($categories,fn($item)=>is_string($item) && in_array($item,$allowed,true))));
    if (!is_string($input['message'] ?? '')) throw new InvalidArgumentException('Invalid message.');
    $message=trim($input['message'] ?? ''); if (mb_strlen($message)>500) throw new InvalidArgumentException('Messages must be 500 characters or fewer.');
    if (!$status && !$mood && $message==='' && !array_filter($values) && !$categories) throw new InvalidArgumentException('Please choose at least one response.');
    db()->beginTransaction();
    try {
        // Use the same class lock as the teacher's open/close action.
        $q=db()->prepare('SELECT c.id FROM classes c JOIN enrollments en ON en.class_id=c.id WHERE c.id=? AND en.student_id=? FOR UPDATE'); $q->execute([$classId,$studentId]);
        if (!$q->fetch()) throw new DomainException('Not enrolled in this class',403);
        $q=db()->prepare('SELECT id FROM sessions WHERE class_id=? AND ended_at IS NULL ORDER BY id DESC LIMIT 1 FOR UPDATE'); $q->execute([$classId]); $sessionId=(int)$q->fetchColumn();
        if (!$sessionId) throw new DomainException('Your instructor has closed feedback. You are still signed in.',409);
        if ($sessionId!==$expectedSession) throw new DomainException('A new lesson session has started. Reload this page before submitting.',409);
        if (time()-($_SESSION['live_last_submit'][$sessionId] ?? 0)<SUBMIT_COOLDOWN) throw new DomainException('Please wait a few seconds before sending again.',429);
        db()->prepare('INSERT INTO responses (session_id,status,mood,message,clarity,pace,understanding,environment,participation,categories) VALUES (?,?,?,?,?,?,?,?,?,?)')->execute([$sessionId,$status,$mood,$message!=='' ? $message : null,...$values,implode(',',$categories)]);
        // Participation records no response ID or content; feedback stays anonymous.
        db()->prepare('INSERT IGNORE INTO participation (session_id,student_id) VALUES (?,?)')->execute([$sessionId,$studentId]);
        db()->commit(); $_SESSION['live_last_submit'][$sessionId]=time(); return $sessionId;
    } catch (Throwable $error) { if (db()->inTransaction()) db()->rollBack(); throw $error; }
}
