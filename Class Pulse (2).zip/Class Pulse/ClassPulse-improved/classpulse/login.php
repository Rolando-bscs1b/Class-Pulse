<?php require 'includes/bootstrap.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $_SESSION['fails'] = $_SESSION['fails'] ?? 0;
    if ($_SESSION['fails'] >= 5 && time() - ($_SESSION['fail_t'] ?? 0) < 60) $err = 'Too many attempts. Please wait a minute.';
    else {
        $id = strtolower(trim($_POST['identifier'] ?? ''));
        $s = db()->prepare('SELECT id,password_hash FROM students WHERE student_number=? OR LOWER(email)=?');
        $s->execute([$id, $id]); $row = $s->fetch();
        if ($row && $row['password_hash'] && password_verify($_POST['password'] ?? '', $row['password_hash'])) {
            session_regenerate_id(true);
            unset($_SESSION['admin_id'], $_SESSION['teacher_id']);
            $_SESSION['student_id'] = (int)$row['id'];  // used ONLY for enrollment/participation, never stored with responses
            header('Location: classes.php'); exit;
        }
        $_SESSION['fails']++; $_SESSION['fail_t'] = time();
        $err = 'Invalid student number / CvSU email or password.';
    }
}
page_head('Student Login'); $authRole = 'student'; require __DIR__ . '/includes/auth-view.php'; page_foot();
