<?php
require __DIR__.'/../includes/live.php'; require_student(true);
if ($_SERVER['REQUEST_METHOD']!=='POST') json_out(['error'=>'Use POST to submit feedback.'],405);
$input=json_decode(file_get_contents('php://input'),true);
if (!is_array($input)) json_out(['error'=>'Invalid request.'],400);
if (empty($_SESSION['csrf']) || !is_string($input['csrf'] ?? null) || !hash_equals($_SESSION['csrf'],$input['csrf'])) json_out(['error'=>'Invalid request.'],403);
try { $sessionId=save_live_feedback((int)$_SESSION['student_id'],$input); json_out(['ok'=>true,'session_id'=>$sessionId]); }
catch (InvalidArgumentException $error) { json_out(['error'=>$error->getMessage()],422); }
catch (DomainException $error) { json_out(['error'=>$error->getMessage()],$error->getCode() ?: 409); }
catch (PDOException $error) { error_log('Live feedback database error: '.$error->getCode()); json_out(['error'=>'Could not save your feedback. Please try again.'],503); }
