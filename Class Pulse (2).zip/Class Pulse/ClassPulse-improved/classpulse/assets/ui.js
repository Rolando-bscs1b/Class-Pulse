document.querySelectorAll('[data-password]').forEach(button => {
  button.addEventListener('click', () => {
    const input = document.getElementById(button.dataset.password);
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    button.textContent = show ? 'Hide' : 'Show';
    button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    button.setAttribute('aria-pressed', String(show));
  });
});
document.querySelectorAll('[data-table-search]').forEach(input => {
  const table = document.getElementById(input.dataset.tableSearch);
  const rows = Array.from(table.querySelectorAll('tbody tr[data-search-row]'));
  const result = document.getElementById(input.dataset.tableSearch + '-result');
  input.addEventListener('input', () => {
    const query = input.value.trim().toLocaleLowerCase();
    let visible = 0;
    rows.forEach(row => {
      row.hidden = !row.dataset.searchRow.toLocaleLowerCase().includes(query);
      if (!row.hidden) visible++;
    });
    if (result) result.textContent = visible ? `${visible} ${visible === 1 ? 'record' : 'records'} shown` : 'No matching records. Try another search.';
  });
});
document.querySelectorAll('[data-class-metadata]').forEach(form=>{
  form.querySelector('select[name="class_id"]').addEventListener('change',event=>{
    const option=event.target.selectedOptions[0];
    for (const [field,key] of [['branch','branch'],['department','department'],['schedule_code','scheduleCode'],['section_name','sectionName']]) { const input=form.querySelector(`[name="${field}"]`); if(input) input.value=option.dataset[key] || ''; }
  });
});
