(() => {
  const tools=document.querySelector('[data-task-tools]'); if (!tools) return;
  const cards=[...document.querySelectorAll('[data-evaluation-task]')];
  const search=tools.querySelector('[data-task-search]'), size=tools.querySelector('[data-task-page-size]');
  const buttons=[...tools.querySelectorAll('[data-task-filter]')], count=document.querySelector('[data-task-count]');
  const previous=document.querySelector('[data-task-prev]'), next=document.querySelector('[data-task-next]'), empty=document.querySelector('[data-task-empty]');
  let status='all', page=0;
  function render() {
    const query=search.value.trim().toLocaleLowerCase(), matches=cards.filter(card=>(status==='all'||card.dataset.taskStatus===status)&&card.dataset.taskSearch.toLocaleLowerCase().includes(query));
    const perPage=Number(size.value); page=Math.max(0,Math.min(page,Math.max(0,Math.ceil(matches.length/perPage)-1)));
    const visible=new Set(matches.slice(page*perPage,(page+1)*perPage)); cards.forEach(card=>card.hidden=!visible.has(card));
    count.textContent=matches.length ? `Showing ${page*perPage+1}–${Math.min((page+1)*perPage,matches.length)} of ${matches.length} evaluations` : 'No matching evaluations';
    previous.disabled=page===0; next.disabled=(page+1)*perPage>=matches.length; if(empty) empty.hidden=matches.length>0;
  }
  search.addEventListener('input',()=>{page=0;render();}); size.addEventListener('change',()=>{page=0;render();});
  buttons.forEach(button=>button.addEventListener('click',()=>{status=button.dataset.taskFilter;page=0;buttons.forEach(item=>item.setAttribute('aria-pressed',String(item===button)));render();}));
  previous.addEventListener('click',()=>{page--;render();}); next.addEventListener('click',()=>{page++;render();}); render();
})();
