<?php require __DIR__ . '/../includes/bootstrap.php'; require_admin();
$n = fn($t) => db()->query("SELECT COUNT(*) FROM $t")->fetchColumn();
$rows = db()->query("SELECT c.id,c.code,c.title,c.section_name,t.name teacher,
  (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id) enrolled,
  (SELECT COUNT(*) FROM sessions s WHERE s.class_id=c.id AND s.ended_at IS NULL) open_now,
  (SELECT COUNT(*) FROM responses r JOIN sessions s ON s.id=r.session_id WHERE s.class_id=c.id) resp
  FROM classes c JOIN teachers t ON t.id=c.teacher_id ORDER BY c.code")->fetchAll();
page_head('Admin Dashboard'); include __DIR__ . '/nav.php'; ?>
<main class="container portal admin-portal py-4">
  <header class="portal-heading"><div class="dashboard-eyebrow">ADMINISTRATION</div><h1>School overview</h1><p>Manage your learning community and monitor feedback across all classes.</p></header>
  <section class="card set-dashboard-callout mb-4"><div><span class="dashboard-eyebrow">TEACHING QUALITY</span><h2>Student Evaluation of Teaching</h2><p>Open SET cycles, review identified submissions, and release anonymous results to instructors.</p></div><a class="btn btn-dark" href="evaluations.php">Manage SET ↗</a></section>
  <div class="row g-3 mb-4">
    <?php foreach ([['Instructors','Create accounts and assign teaching responsibilities.','instructors'],['Classes','Organize classes and instructor assignments.','classes'],['Students','Manage student accounts and class enrollment.','students']] as [$title,$description,$tab]): ?>
      <div class="col-md-4"><a class="portal-action card p-3 h-100" href="manage.php?t=<?= $tab ?>"><strong><?= $title ?> <span aria-hidden="true">↗</span></strong><span><?= $description ?></span></a></div>
    <?php endforeach; ?>
  </div>
  <div class="row g-3 mb-3 text-center">
    <?php foreach (['Students'=>'students','Instructors'=>'teachers','Classes'=>'classes','Responses'=>'responses'] as $l=>$t): ?>
    <div class="col-6 col-md-3"><div class="card p-3"><small><?= $l ?></small><div class="display-6"><?= $n($t) ?></div></div></div><?php endforeach; ?>
  </div>
  <section class="card records-card"><div class="records-heading"><div><h2>Classes &amp; live sessions <span class="record-count"><?= count($rows) ?></span></h2><p>A pulse on what’s happening across your campus.</p></div><label class="search-field"><span class="visually-hidden">Search campus classes</span><input type="search" class="form-control" placeholder="Search class or instructor…" data-table-search="overview-table"></label></div>
    <div class="table-responsive"><table id="overview-table" class="table align-middle"><thead><tr><th>Class</th><th>Instructor</th><th>Enrolled</th><th>Responses</th><th>Status</th><th><span class="visually-hidden">Actions</span></th></tr></thead><tbody>
    <?php foreach ($rows as $r): ?><tr data-search-row="<?= e($r['code'].' '.$r['title'].' '.$r['teacher'].' '.$r['section_name']) ?>"><td><span class="class-code"><?= e($r['code']) ?></span> <span class="section-label"><?= e($r['section_name'] ?: 'Section not assigned') ?></span><div class="person-name mt-2"><?= e($r['title']) ?></div></td><td><?= e($r['teacher']) ?></td><td><?= $r['enrolled'] ?></td><td><?= $r['resp'] ?></td>
      <td><span class="badge <?= $r['open_now']?'bg-success':'bg-secondary' ?>"><?= $r['open_now']?'Open':'Closed' ?></span></td>
      <td><a class="btn btn-dark btn-sm" href="dashboard.php?class_id=<?= $r['id'] ?>">Class insights</a></td></tr><?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="6" class="text-muted py-4">No classes yet. Add an instructor and class to get started.</td></tr><?php endif; ?>
    </tbody></table></div><p id="overview-table-result" class="records-result" role="status"><?= count($rows) ?> classes shown</p></section>
</main><?php page_foot();
