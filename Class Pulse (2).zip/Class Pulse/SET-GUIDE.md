# Student Evaluation of Teaching

SET is separate from live classroom feedback. Live responses remain anonymous to everyone, including administrators. SET submissions are identifiable to administrators and anonymous in teacher-facing results.

## Students

Open **Teaching evaluation (SET)** from the student dashboard. The dark **My Evaluation Tasks** workspace supports searching, status filters, cycle selection, and 9/18/36 tasks per page. Cards show the instructor, branch, department, subject code, schedule code, subject title, dates, and completion status.

New cycles use the 15 statements supplied by the user, grouped into management of teaching and learning, subject knowledge and teaching strategies, and assessment and student support. The scale is 5 = Always manifested, 4 = Often manifested, 3 = Sometimes manifested, 2 = Seldom manifested, 1 = Never/Rarely manifested. All 15 ratings are required. **D. Other Comments and Suggestions** is optional, up to 1,500 characters. The details sidebar counts 16 questions including this comment field.

There is one submission per enrolled class per cycle. Completed cards open the student's own recorded answers in view-only mode. They cannot be edited. Students are informed before submission that admins can identify them and that comments should omit personal details. Existing eight-question responses retain their original questions, agreement scale, and scores; they are never relabeled as answers to the new questionnaire.

## Teachers

Open **My SET results**. The matching task-card workspace lists only your own classes and results. Select a cycle, search or filter the cards, and choose **View results**. The details sidebar and result sections match the student form. Results contain criterion averages, an overall average, and unattributed comments. Student names, numbers, individual ratings, submission IDs, exact timestamps, and submission order are excluded from the teacher-facing data and page.

Scores and comments are available only when the cycle is closed, an admin has released results, and at least three evaluations exist for that teacher/class/cycle group. Smaller groups remain suppressed. Evaluations stay attached to the instructor who was evaluated, even if the class is reassigned later.

## Admins

SET is hidden from students and teachers by default. Open **Admin → SET** and select **Turn on SET** to show its navigation, dashboard cards, and pages. Select **Hide SET** to remove them again and stop submissions, including forms opened before hiding. Direct student/teacher SET links are blocked while hidden. Admins can still review records and manage cycles.

Visibility is separate from cycle status and result release: turning SET on does not reopen a closed cycle or release results. Hiding it does not delete records or close a cycle. Existing installations must import `migrations/002_set_visibility.sql` to add this control. A fresh installation has an open starter cycle but keeps SET hidden until an admin turns it on.

Open **SET** from the admin dashboard. **Open a new cycle** creates a 15-question cycle with optional start and due dates in Asia/Manila time. Server-side checks reject submissions before the start or after the due date. Creating another cycle closes the currently open one and preserves its records. Closed cycles cannot be reopened through the interface. Existing cycles with recorded eight-question responses keep that form; open a new cycle to use the 15-question version.

**Manage class details shown on SET cards** lets admins set the real branch, department, and schedule code for each class. Missing department and schedule values display as **Not specified**. They are not invented from the screenshots.

Filter results by cycle and instructor. The identified-submissions table lists students, instructors, classes, and scores. **View evaluation** shows the student's name, student number, email, submission time, all ratings, and comments. Teachers and students cannot access this page.

## Installation and database

The local installation and `classpulse_revised` database have been updated. No existing live feedback was changed. A pre-change backup is saved as `ClassPulse-before-SET.sql`.

The updated ZIP includes the schema for fresh installs. Existing installations should apply missing migrations in order: `001_set.sql`, `002_set_visibility.sql`, and `003_set_reference.sql`. This local installation already has all three. The 15-question upgrade backup is `ClassPulse-before-15-question-SET.sql`. Use migrations to upgrade a database with real records instead of importing a full export over it.

## Validation

`tests/set-integration.php` covers both questionnaire versions, validation, enrollment, instructor snapshots, duplicate prevention, scheduled/expired cycles, privacy thresholds, release gating, scores, escaped comments, teacher data isolation, admin identification, and read-only completion. Its fixtures are rolled back. `tests/set-tasks.test.cjs` checks search, tabs, pagination, page sizes, and empty states. `tests/set-visibility-smoke.ps1` checks installed routes, CSRF protection, role access, and hidden/enabled states, leaving SET hidden. Desktop and phone previews were inspected without saving real evaluations. Existing dashboard and live-feedback tests also passed.
